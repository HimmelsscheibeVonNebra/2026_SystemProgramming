# Week05-class01 · 시스템 정보와 자원 한계 실습 기록지

- 이름 / 학번:
- 운영체제·커널 릴리스·아키텍처:
- 실행한 빌드 명령과 결과:

## 1. 시스템 식별

| 항목 | sysprobe 출력 | uname / 명령 출력 | 일치 여부 |
|---|---|---|---|
| sysname | | uname -s | |
| nodename | | uname -n | |
| release | | uname -r | |
| machine | | uname -m | |
| cpus_online | | getconf NPROCESSORS_ONLN | |
| pagesize | | getconf PAGE_SIZE | |
| clk_tck | | getconf CLK_TCK | |
| open_max | | getconf OPEN_MAX / ulimit -Sn | |
| arg_max | | getconf ARG_MAX | |

- sysinfo_demo 실행 결과(또는 Linux 전용 안내 관찰):
- uname 실패 후 구조체 필드를 읽으면 안 되는 이유:

## 2. sysconf 반환 계약

- 호출 직전에 errno를 0으로 만들어야 하는 이유:
- -1을 돌려받았을 때 두 가지 경우와 구분 방법:
- 내 환경의 pagesize와 clk_tck 값, 그 값을 코드에 상수로 박아 넣으면 안 되는 이유:

## 3. FD 한계

| 단계 | soft (ulimit -Sn) | hard (ulimit -Hn) | opened | stopped |
|---|---|---|---|---|
| 기본 | | | | |
| --raise 64 | | | | |
| --raise 4096 | | | | |
| bash -c 'ulimit -Sn 64 && ./nofile_demo' | | | | |

- opened가 soft와 정확히 같지 않은 이유:
- EMFILE을 만난 뒤 프로그램이 하는 일:
- 프로그램이 바꾼 한계가 부모 셸에 영향을 주지 않는 이유:
- ulimit -n 대신 ulimit -Sn을 쓰는 이유:

## 4. /proc 관찰

| 항목 | proc_probe 출력 | 명령으로 확인한 값 | 다르게 나온 경우의 이유 |
|---|---|---|---|
| VmRSS | | grep /proc/self/status | |
| Threads | | grep /proc/self/status | |
| loadavg 첫 줄 | | cat /proc/loadavg | |
| fd 개수 | | ls /proc/self/fd | wc -l | |
| open files 한계 | | grep 'open files' /proc/self/limits | |

- /proc/self/status의 self가 가리키는 대상:
- 프로그램의 판단 근거는 표준 API, 진단은 /proc로 나누는 이유:

## 5. 정리

- 오늘 배운 조회 호출에 공통으로 들어 있는 반환값 패턴:
- 값이 환경마다 다를 때 두 문으로 교차 확인하는 이유:
