# Week05-class01 실습 · 시스템 정보와 자원 한계

Ubuntu 일반 사용자 환경에서 프로그램이 자기 실행 환경을 알아내는 방법을 실습합니다. 준비 도구는 `cc`, `make`, `python3`입니다. 명령은 이 README가 있는 폴더에서 실행합니다.

```sh
make
make check
```

| 예제 | 학습 내용 |
|---|---|
| sysprobe.c | uname(2) 필드와 sysconf(3) 경계값, -1 반환 계약 |
| limit_show.c | getrlimit(2), soft·hard 한계, RLIM_INFINITY 출력 |
| nofile_demo.c | FD 한계 실험, EMFILE, setrlimit로 soft 변경 |
| proc_probe.c | /proc/self/status·loadavg·fd 관찰, fgets 필터 |
| sysinfo_demo.c | Linux 전용 sysinfo(2), 조건부 컴파일 |

Makefile은 C11과 POSIX API를 사용하며 경고를 오류로 처리합니다. `_FILE_OFFSET_BITS=64`는 32비트 Linux의 파일 크기 표현을 위한 설정입니다. `_DEFAULT_SOURCE`와 `_DARWIN_C_SOURCE`는 각각 Linux와 macOS의 구조체·상수 선언을 위한 설정입니다.

출력 값은 실행 환경마다 다릅니다. 숫자를 고정하지 말고, 서로 다른 문(프로그램·명령)에서 같은 값이 나오는지와 변경 실험 전후의 관계를 기록하는 것이 이번 실습의 목적입니다.

## 실습 1 · 시스템 식별

같은 터미널에서 이어서 실행합니다.

```sh
./sysprobe
uname -a
uname -r
uname -m
```

관찰할 점:

- `sysname`, `release`, `machine`이 uname 명령의 어느 열과 대응하는지 표로 정리합니다.
- `cpus_online`, `pagesize`, `clk_tck`, `open_max`, `arg_max`의 값을 적습니다.
- Ubuntu에서 시스템 호출 관찰: `strace -e uname ./sysprobe`
- `./sysinfo_demo`는 Linux에서만 uptime·loadavg·램 정보를 출력합니다. 다른 운영 체제에서는 Linux 전용 안내 문장과 종료 상태 1을 확인합니다. 조건부 컴파일(`#ifdef __linux__`)로 이식성과 플랫폼 확장을 구분하는 예시입니다.

Ubuntu 22.04의 일반적인 값은 `pagesize=4096`, `clk_tck=100`이지만 환경에 따라 다릅니다. macOS에서는 `pagesize`가 16384로 나오는 것도 정상입니다.

## 실습 2 · sysconf 반환 계약과 경계값

`sysprobe.c`의 `probe` 함수를 읽고 다음을 확인합니다.

```c
errno = 0;
long value = sysconf(name);
if (value == -1) {
    if (errno != 0) { /* 조회 실패 */ }
    else            { /* 무한 또는 값을 정할 수 없음 */ }
}
```

셸에서 같은 값을 교차 확인합니다.

```sh
getconf PAGE_SIZE
getconf CLK_TCK
getconf NPROCESSORS_ONLN
getconf OPEN_MAX
ulimit -Sn
```

관찰할 점:

- `getconf OPEN_MAX`와 `ulimit -Sn`이 같은 숫자인지, `sysprobe`의 `open_max`와도 같은지 비교합니다.
- sysconf는 실패해도 errno를 바꾸지 않을 수 있으므로 호출 직전에 errno를 0으로 만드는 것이 계약의 일부입니다.
- macOS에서는 일부 기본값이 Linux와 다릅니다. 값의 차이를 그대로 기록해도 됩니다.

## 실습 3 · FD 한계와 setrlimit

```sh
./limit_show
./limit_show | head -1
./nofile_demo
./nofile_demo --raise 64
./nofile_demo --raise 4096
bash -c 'ulimit -Sn 64 && ./nofile_demo'
bash -c 'ulimit -Sn 4096; ./nofile_demo'
```

관찰할 점:

- `nofile`의 soft·hard 값을 `ulimit -Sn`, `ulimit -Hn`, `/proc/self/limits`(Linux)와 비교합니다.
- `opened`는 soft 한계 근처에서 멈춥니다. 표준 입출력 오류 FD 세 개가 이미 열려 있으므로 soft와 정확히 같지 않습니다.
- `--raise 64`: soft를 64로 바꾼 뒤 측정합니다. 기본 soft가 이미 크면 이것은 하향 실험입니다.
- `--raise 4096`: hard 이하라면 상향됩니다. hard보다 크면 nofile_demo가 hard로 제한합니다. 셸에서 hard 초과 상향은 허용 오류가 남을 비교합니다.
- 셸 실험은 새 `bash` 안에서만 한계가 바뀌는지 확인하는 것이 목적입니다. `ulimit -Sn`은 soft만 바꿉니다. `-S` 없이 `ulimit -n N`을 쓰면 soft와 hard가 함께 바뀌어 hard를 되돌릴 수 없으므로 실습에서는 쓰지 않습니다.

한 번 `EMFILE`을 만나면 프로그램은 연 모든 FD를 닫고 정상 종료합니다. 실패 경로에서도 자원을 반환하는지 `nofile_demo.c`의 정리 코드에서 확인합니다.

## 실습 4 · /proc 관찰 창

```sh
./proc_probe
grep -E 'VmRSS|Threads' /proc/self/status
cat /proc/loadavg
ls /proc/self/fd | wc -l
grep 'open files' /proc/self/limits
head -3 /proc/meminfo
```

관찰할 점:

- `proc_probe`가 출력한 `VmRSS`, `Threads`, loadavg 첫 줄, fd 개수를 각 명령의 출력과 줄 단위로 맞춥니다.
- `grep /proc/self/status`의 `self`는 grep 프로세스 자신입니다. 명령마다 프로세스가 다르므로 값이 조금씩 다른 것이 정상이며, 그 이유를 설명하는 것이 핵심입니다.
- `/proc/self/fd`를 opendir로 여는 순간 그 스트림 자체가 FD 하나를 추가하므로 개수 해석에 주의합니다.
- `/proc/self/limits`의 `open files` 줄이 `limit_show`의 nofile 값과 같은지 확인합니다.
- macOS 등 /proc가 없는 환경에서는 안내 오류와 종료 상태 1이 출력됩니다. 이것도 관찰 결과로 기록합니다.

## 종료 상태와 제출

- 0: 정상 완료
- 1: 조회·변경·관찰 실패 (Linux 전용 인터페이스를 지원하지 않는 환경 포함)
- 2: 잘못된 실행 인자

실패 직후 `echo $?`를 실행합니다. 의도적인 실패가 있으므로 모든 명령을 `set -e`로 일괄 실행하지 않습니다.

제출물은 C 소스 5개, Makefile, 작성한 REPORT.md, 정상·실패 실행 로그입니다. 선택 과제는 `sysprobe`에 `pathconf(".", _PC_NAME_MAX)` 항목을 추가하는 것입니다.

## 실행 확인 범위

2026-09-27 macOS arm64에서 다섯 예제를 경고 없이 컴파일하고 자동 검사 9회 실행을 통과했습니다. uname 필드와 시스템 값 일치, sysconf 반환 계약, rlimit soft·hard 일치, FD 한계 도달(EMFILE)과 setrlimit 전후 측정, /proc 미지원 환경의 오류 경로를 검사했습니다. Linux 실행은 이번 제작 환경에서 확인하지 않았으므로 수업용 Ubuntu에서 `make check`로 재확인할 수 있습니다. Docker 데몬이 실행 중이면 week02의 Ubuntu 이미지로 Linux 동작(sysinfo 출력, /proc 관찰)을 미리 확인할 수 있습니다.

## 참고

[uname(2)](https://man7.org/linux/man-pages/man2/uname.2.html), [sysinfo(2)](https://man7.org/linux/man-pages/man2/sysinfo.2.html), [sysconf(3)](https://man7.org/linux/man-pages/man3/sysconf.3.html), [pathconf(3)](https://man7.org/linux/man-pages/man3/pathconf.3.html), [getrlimit(2)](https://man7.org/linux/man-pages/man2/getrlimit.2.html), [proc(5)](https://man7.org/linux/man-pages/man5/proc.5.html).
