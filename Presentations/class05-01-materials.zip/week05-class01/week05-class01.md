# Week05-class01 · 시스템 정보와 자원 한계

120분 수업(휴식 10분 포함), 슬라이드 35장. uname·sysconf로 실행 환경을 알아내고 getrlimit로 자원 한계를 다루며 /proc로 관찰합니다.

## 1. 시스템 정보와 자원 한계

교수자 메모: 지난 두 주는 파일의 내용·속성·이름을 다뤘다. 오늘은 프로그램이 자기 실행 환경을 알아내는 인터페이스를 다룬다. 표준 API와 Linux 관찰 창을 구분하는 것이 이번 시간의 핵심 문제다.

## 2. 수업 구성

복습과 1부  시스템 식별 · 30분

2부  sysconf와 경계값 · 25분

3부  자원 한계 · 30분

4부  /proc 관찰 창 · 20분

확인 퀴즈와 제출 · 5분

120분 수업 · 1부 후 휴식 10분

교수자 메모: 1부를 마친 뒤 휴식 10분을 포함해 총 120분이다. 전반부는 실행 환경을 알아내는 조회 API의 계약을, 후반부는 자원 한계와 /proc 관찰을 다룬다.

## 3. 왜 시스템 정보를 읽는가

실행 환경은 매번 다르다: 커널, CPU, 메모리, 열린 파일 상한.

진단 로그: 오류 보고에 시스템 식별 정보를 함께 남긴다.

이식성: 컴파일할 때 정하지 않고 실행할 때 값을 얻는다.

자원 계획: 버퍼 크기나 동시 작업 수를 한계 안에서 정한다.

2주차에 uname·sysconf 예제를 잠깐 실행했습니다. 오늘은 계약까지 다룹니다.

교수자 메모: 같은 프로그램도 실행 환경에 따라 동작 조건이 달라진다. 페이지 크기, CPU 수, 열린 파일 상한을 상수로 가정하면 다른 환경에서 실패한다. 오늘 배우는 호출은 모두 값을 얻는 조회이며, 반환값 검사가 곧 프로그램의 첫 단계다.

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 4. 1부 시스템 식별

uname과 sysinfo로 실행 환경을 확인합니다.

## 5. uname(2)과 struct utsname

sysname / nodename: 커널 이름과 네트워크상의 호스트 이름이다.

release / version: 커널 릴리스와 빌드 정보 문자열이다.

machine: CPU 아키텍처 이름이다. x86_64, aarch64 등이다.

헤더: <sys/utsname.h>. 성공 0, 실패 -1입니다.

교수자 메모: 헤더는 <sys/utsname.h>이고 성공 0, 실패 -1이다. version 문자열의 형식은 배포판마다 다르다. domainname 필드는 Linux 확장이다. nodename이 항상 호스트 이름과 일치하지는 않는다(컨테이너 등).

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 6. sysprobe: uname 조회

호출 결과: 성공 0, 실패 -1이다. 실패하면 errno를 본다.

문자열 필드: 구조체 안에 들어 있는 널 종료 문자열이다.

출력 시점: 조회에 성공한 뒤에만 필드를 읽는다.

```sh
#include <sys/utsname.h>

struct utsname u;
if (uname(&u) == -1) {
    perror("uname");
    return 1;
}
printf("sysname=%s\n", u.sysname);
printf("nodename=%s\n", u.nodename);
printf("release=%s\n", u.release);
printf("machine=%s\n", u.machine);
```

완성 예제: labs/class05-01/sysprobe.c

교수자 메모: sysname 값으로 운영 체제를 구분하는 코드를 만들 수 있다. 완성 sysprobe는 버전 필드와 sysconf 결과까지 함께 출력한다.

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 7. uname(1) 명령과 비교

명령과 함수: uname(1)은 같은 정보를 셸에서 확인한다.

함수의 쓰임: 프로그램 안에서 로그나 환경 판별에 사용한다.

출력 차이: 버전 문자열 형식은 배포판마다 다르다.

```sh
$ uname -a
Linux lab-ubuntu 6.8.0-49-generic #49-Ubuntu \
SMP ... x86_64 GNU/Linux

# -s Linux             -n lab-ubuntu
# -r 6.8.0-49-generic  -m x86_64

$ uname -r
6.8.0-49-generic
$ uname -m
x86_64
```

출력 예시: Ubuntu 22.04 환경입니다.

교수자 메모: 화면의 출력은 Ubuntu 예시다. macOS에서는 sysname이 Darwin이고 machine이 arm64처럼 나온다. 값 자체보다 어떤 필드가 어느 열에 대응하는지가 중요하다.

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 8. sysinfo(2): 자원 요약

구조체 필드: uptime, loads, totalram, freeram, procs 등이 있다.

단위 환산: 램 필드 값에 mem_unit을 곱해 바이트로 만든다.

Linux 전용: 표준 인터페이스가 아니므로 이식성 코드와 구분한다.

헤더: <sys/sysinfo.h>. Linux 전용입니다.

교수자 메모: loads는 65536을 1로 하는 고정소수점 값이다. 같은 정보를 /proc/meminfo와 /proc/loadavg에서도 읽을 수 있다. sysinfo_demo는 Linux가 아니면 안내 문장을 출력하고 실패 상태로 끝난다.

참고: [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html)

## 9. 실습 1: 시스템 식별 관찰

uname 비교: sysprobe 출력과 uname 명령의 열을 맞춘다.

호출 관찰: strace로 uname 시스템 호출을 확인한다.

전용 인터페이스: sysinfo_demo는 Linux에서만 결과를 출력한다.

```sh
./sysprobe
uname -a
uname -r
uname -m

# Ubuntu에서 시스템 호출 관찰
strace -e uname ./sysprobe

# Linux에서만 동작
./sysinfo_demo
```

값을 예측한 뒤 REPORT.md에 기록합니다.

교수자 메모: sysprobe의 각 줄이 uname의 어느 옵션과 같은지 표로 적는다. macOS 실습 환경에서는 sysinfo_demo가 Linux 전용 안내를 출력하는 것도 관찰 결과다.

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html)

## 10. 2부 sysconf와 경계값

실행 시점에 시스템 경계값을 조회합니다.

## 11. sysconf(3)의 역할

실행 시점 조회: 컴파일할 때 정하지 않고 실행할 때 값을 얻는다.

인자 형태: _SC_ 접두사 상수로 조회할 값을 고른다.

반환형: long이다. 오류와 무한 값을 -1로 함께 표현할 수 있다.

헤더: <unistd.h>. 인자는 int, 반환은 long입니다.

교수자 메모: 헤더는 <unistd.h>다. 조회마다 값이 다를 수 있으므로 결과를 저장해 재사용하는 코드와 매번 조회하는 코드의 차이를 생각해 본다.

참고: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 12. sysconf의 반환값 계약

호출 직전에 errno를 0으로 만든다.

-1이고 errno가 0이면: 한계가 없거나 값을 정할 수 없다.

-1이고 errno가 0이 아니면: 조회 자체가 실패했다.

결론: -1 하나로 두 가지 뜻을 나눠 읽는다.

조회에 성공한 값을 얻은 뒤에 프로그램이 사용한다.

교수자 메모: sysconf는 실패해도 errno를 바꾸지 않을 수 있다. 그래서 호출 전에 errno를 0으로 초기화하는 관습이 필요하다. 지원하지 않는 name은 EINVAL으로 실패한다. 이 읽기법은 -1과 errno의 조합으로 상태를 나누는 대표 사례다.

참고: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 13. 자주 쓰는 _SC 상수

_SC_PAGESIZE: 메모리 페이지 크기. 정렬과 mmap 계산에 쓴다.

_SC_NPROCESSORS_ONLN: 지금 사용 가능한 온라인 CPU 수다.

_SC_CLK_TCK: times(2) 값의 초당 틱 수다. CPU 시간 환산에 쓴다.

교수자 메모: _SC_OPEN_MAX는 FD의 soft 한계 값이고 _SC_ARG_MAX는 exec 인자와 환경의 총 크기 상한이다. x86_64 Linux에서 PAGESIZE 4096, CLK_TCK 100이 흔하지만 코드에 박아 넣지 않고 조회해 쓴다.

참고: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html)

## 14. sysprobe: sysconf 읽기

초기화: 호출 직전에 errno를 0으로 만든다.

두 갈래: -1 뒤 errno의 값으로 실패와 무한을 나눈다.

재사용: probe 함수로 여러 값을 같은 계약으로 읽는다.

```c
static int probe(const char *label, int name)
{
    errno = 0;
    long value = sysconf(name);
    if (value == -1) {
        if (errno != 0) {
            perror(label);
            return 1;
        }
        printf("%s=unlimited\n", label);
        return 0;
    }
    printf("%s=%ld\n", label, value);
    return 0;
}
```

완성 예제: sysprobe.c

교수자 메모: 완성 sysprobe는 cpus_online, pagesize, clk_tck, open_max, arg_max를 이 함수로 출력한다. 라벨을 인자로 받으면 오류 메시지가 어느 조회인지 알려준다.

참고: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 15. 페이지 크기와 CLK_TCK가 쓰이는 곳

페이지 크기: 메모리를 다루는 최소 단위다. 11주 mmap에서 다시 만난다.

CLK_TCK: times(2)가 돌려준 틱을 초로 환산할 때 나눈다.

CPU 수: 작업 분배나 스레드 수를 정하는 근거가 된다.

값은 아키텍처·커널에 따라 다르다: x86_64는 4096과 100이 흔하다.

같은 프로그램으로 여러 환경의 값을 비교하는 것도 과제다.

교수자 메모: Apple Silicon은 16384바이트 페이지를 쓴다. sysconf(_SC_PAGESIZE)는 getpagesize()보다 표준적인 방법이다. CLK_TCK는 다음 시간에 배울 시간 처리에서 times와 짝으로 쓰인다.

참고: [getpagesize.2](https://man7.org/linux/man-pages/man2/getpagesize.2.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html)

## 16. pathconf와 fpathconf

파일시스템 경계값: 같은 상수라도 대상 파일시스템에 따라 다르다.

_PC_NAME_MAX: 그 디렉토리에서 파일 이름의 최대 길이다.

_PC_PATH_MAX: 경로 문자열의 최대 길이다.

헤더: <unistd.h>. 반환값 계약은 sysconf와 같습니다.

교수자 메모: pathconf는 경로를, fpathconf는 열린 FD를 기준으로 삼는다. 반환값 계약은 sysconf와 같다. Linux의 PATH_MAX 제한은 실제로는 더 긴 경로도 다루는 경우가 있어 문서를 함께 읽는다.

참고: [pathconf.3](https://man7.org/linux/man-pages/man3/pathconf.3.html)

## 17. 실습 2: 경계값 비교

getconf: sysconf가 주는 값을 셸에서 확인한다.

ulimit -Sn: FD의 soft 한계를 확인한다.

두 번 확인: 같은 값을 다른 문으로 맞춰 본다.

```sh
./sysprobe

# 같은 값을 셸에서 확인 (Linux)
getconf PAGE_SIZE
getconf CLK_TCK
getconf NPROCESSORS_ONLN
getconf OPEN_MAX

# FD 한계는 3부에서 다룬다
ulimit -Sn
```

값을 예측한 뒤 REPORT.md에 기록합니다.

교수자 메모: getconf OPEN_MAX와 ulimit -Sn이 같은 숫자인지, sysprobe의 open_max와도 같은지 비교한다. macOS에서는 일부 기본값이 달라진다. 값이 다르다면 그 이유를 문서에서 찾는다.

참고: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 18. 3부 자원 한계

getrlimit과 setrlimit로 프로세스의 상한을 다룹니다.

## 19. getrlimit과 setrlimit

struct rlimit: rlim_cur는 soft 한계, rlim_max는 hard 한계다.

getrlimit: 현재 값을 구조체로 얻는다. 성공 0, 실패 -1이다.

setrlimit: 조건을 만족하면 값을 바꾼다. 거부되면 -1과 EPERM이다.

헤더: <sys/resource.h>. 성공 0, 실패 -1입니다.

교수자 메모: 헤더는 <sys/resource.h>다. 구조체를 채운 뒤에야 필드를 읽는 규칙은 stat과 같다. 값을 바꾼 뒤에는 getrlimit로 실제 값을 다시 확인한다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 20. soft 한계와 hard 한계

soft: 지금 강제되는 한계. 넘으면 호출이 실패하거나 시그널이 온다.

hard: soft가 올라갈 수 있는 상한이다.

일반 사용자는 soft를 hard까지 올릴 수 있다.

hard를 낮추면 일반 사용자는 되돌릴 수 없다.

RLIM_INFINITY는 무제한을 나타내는 특별한 값이다.

교수자 메모: hard를 올리는 것은 보통 특권이 필요하다. bash의 ulimit -n은 -S를 붙이지 않으면 soft와 hard를 함께 바꾸므로 실습에서는 ulimit -Sn을 쓴다. 프로그램이 바꾼 한계는 그 프로세스와 이후 자식에만 적용된다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 21. 주요 RLIMIT 종류

RLIMIT_NOFILE: 이 프로세스가 열 수 있는 FD 개수의 상한이다.

RLIMIT_FSIZE / CPU: 파일 크기와 CPU 시간의 상한이다. 초과하면 시그널.

RLIMIT_AS / STACK / NPROC: 주소 공간, 스택, 사용자 프로세스 수의 상한이다.

교수자 메모: Linux의 RLIMIT_NPROC는 실제 사용자 ID별로 계산한다. RLIMIT_CORE는 코어 덤프 크기 상한으로 limit_show가 함께 출력한다. 세부 의미는 getrlimit(2)의 표로 확인한다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 22. limit_show: getrlimit 출력

무제한 표시: RLIM_INFINITY는 unlimited로 표시한다.

자료형: rlim_t를 uintmax_t로 변환해 %ju로 출력한다.

비교 표: 여러 자원의 soft·hard를 한 번에 살펴본다.

```c
struct rlimit rl;
if (getrlimit(RLIMIT_NOFILE, &rl) == -1) {
    perror("getrlimit");
    return 1;
}
printf("%-7s", "nofile");
if (rl.rlim_cur == RLIM_INFINITY)
    printf(" soft=unlimited");
else
    printf(" soft=%ju", (uintmax_t)rl.rlim_cur);
/* hard도 같은 방식으로 출력한다 */
```

완성 예제: limit_show.c

교수자 메모: rlim_t의 크기는 시스템마다 다를 수 있어 printf 형식을 맞추기 위해 uintmax_t로 변환한다. 완성 limit_show는 일곱 종류의 자원을 출력한다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 23. 한계에 도달하면 무슨 일이 생기나

FD 개수 초과: open이 -1을 돌려주고 errno는 EMFILE이다.

파일 크기 초과: write가 EFBIG이고 SIGXFSZ가 갈 수 있다.

CPU 시간 초과: SIGXCPU가 먼저 오고 계속 쓰면 SIGKILL이다.

주소 공간 초과: mmap이나 메모리 할당이 ENOMEM으로 실패한다.

오류 반환과 시그널, 두 형태의 결과가 함께 존재한다.

교수자 메모: 시그널을 다루는 방법은 9주차 주제다. 오늘은 한계 초과가 호출 실패로 나타나는 경우를 직접 관찰한다. 기본 시그널 처리로 끝나는 경우도 있다는 것만 알아 둔다.

참고: [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [signal.7](https://man7.org/linux/man-pages/man7/signal.7.html)

## 24. nofile_demo: FD 한계 실험

실험 설계: 빈 장치 파일을 열 수 있을 때까지 반복한다.

EMFILE: FD 상한에 도달하면 이 오류로 끝난다.

자원 반환: 실험 뒤 열린 FD를 모두 닫는다.

```c
int fd = open("/dev/null", O_RDONLY);
if (fd == -1) {
    if (errno == EMFILE)
        break;            /* 한계 도달 */
    perror("open");
    return 1;
}
fds[opened++] = fd;

/* 실험 뒤 정리 */
while (opened > 0)
    close(fds[--opened]);
```

완성 예제: nofile_demo.c

교수자 메모: 표준 입출력 오류 FD 세 개가 이미 열려 있으므로 opened는 soft 값보다 약간 작다. 배열 크기는 soft 한계에 맞춰 확보한다. 실패해도 연 FD는 모두 닫는다.

참고: [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 25. setrlimit로 soft 한계 바꾸기

상향 범위: 일반 사용자는 hard를 넘어 올릴 수 없다.

적용 범위: 이 프로세스와 이후 자식들에만 적용된다.

변경 확인: getrlimit으로 실제 값을 다시 읽어 출력한다.

```c
struct rlimit rl;
if (getrlimit(RLIMIT_NOFILE, &rl) == -1) {
    perror("getrlimit");
    return 1;
}
/* hard를 넘는 요청은 hard로 제한한다 */
rlim_t target = want > rl.rlim_max
              ? rl.rlim_max : want;
struct rlimit next = { target, rl.rlim_max };
if (setrlimit(RLIMIT_NOFILE, &next) == -1) {
    perror("setrlimit");
    return 1;
}
```

완성 예제: nofile_demo --raise

교수자 메모: 셸에서는 ulimit -Sn N이 같은 역할을 한다. 프로그램이 바꾼 한계는 부모 셸에 영향을 주지 않는다. hard를 넘는 상향 시도가 조용히 hard로 잘리는 것은 이 예제의 동작이고, 셸에서는 허용 오류로 나타난다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 26. 실습 3: FD 한계 관찰

측정: opened가 soft 값 근처에서 멈추는지 확인한다.

변경 실험: --raise 64와 4096으로 soft를 바꿔 비교한다.

셸 비교: ulimit -Sn도 같은 결과를 내는지 본다.

```sh
./limit_show | head -1
./nofile_demo
./nofile_demo --raise 64
./nofile_demo --raise 4096

# 셸에서 soft만 바꿔 비교 (hard 이하)
bash -c 'ulimit -Sn 64 && ./nofile_demo'
bash -c 'ulimit -Sn 4096; ./nofile_demo'
```

값을 예측한 뒤 REPORT.md에 기록합니다.

교수자 메모: 환경에 따라 기본 soft가 이미 클 수 있다. 그럴 때 --raise 64는 하향 실험이 된다. 4096이 hard보다 크면 hard 값으로 잘리는 것도 관찰한다. 셸 실험은 새 bash 안에서만 한계가 바뀌는지 확인하는 것이 목적이다.

참고: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 27. 4부 /proc 관찰 창

표준 API 바깥에서 Linux의 상태를 관찰합니다.

## 28. /proc 파일시스템

커널과 프로세스 상태를 파일처럼 읽는 가상 파일시스템이다.

표준이 아니다: Linux 고유의 관찰 창이다.

프로그램의 판단 근거보다 진단과 스크립트에 쓴다.

읽을 때마다 커널이 그 순간의 상태를 만들어 준다.

지난 주의 opendir·fgets 조합으로 그대로 읽을 수 있다.

교수자 메모: /proc의 파일 크기는 보통 0으로 표시되지만 내용은 있다. 다른 Unix에도 비슷한 메커니즘이 있으나 구조가 다르다. 이식성이 필요한 판단은 표준 API로, 진단은 /proc로 나누는 것이 오늘의 원칙이다.

참고: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 29. /proc의 주요 경로

cpuinfo / meminfo: CPU와 메모리의 전체 요약 정보다.

loadavg: 1, 5, 15분 부하 평균과 작업 수를 한 줄로 준다.

/proc/self/...: 이 프로세스의 상태, 한계, 열린 FD를 가리킨다.

자세한 목록은 proc(5)에 있습니다.

교수자 메모: self는 실행 중인 프로세스 자신으로 풀린다. /proc/self/fd의 항목은 FD 번호 이름의 심볼릭 링크다. pid를 직접 쓰면 다른 프로세스도 관찰할 수 있다.

참고: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 30. proc_probe: /proc/self 관찰

읽기 방법: 3주차의 stdio 함수로 일반 파일처럼 읽는다.

필터: 필요한 줄만 골라 화면에 남긴다.

fd 세기: /proc/self/fd를 opendir로 읽어 개수를 센다.

```c
FILE *f = fopen("/proc/self/status", "r");
if (f == NULL) {
    fprintf(stderr, "/proc/self/status: %s\n",
            strerror(errno));
    return 1;
}
char line[256];
while (fgets(line, sizeof line, f) != NULL)
    if (strncmp(line, "VmRSS:", 6) == 0 ||
        strncmp(line, "Threads:", 8) == 0)
        fputs(line, stdout);
fclose(f);
```

완성 예제: proc_probe.c

교수자 메모: 완성 proc_probe는 loadavg 첫 줄과 fd 개수도 출력한다. /proc/self/fd를 여는 순간 그 스트림 자체가 FD 하나를 추가하므로 개수 해석에 주의한다. VmRSS의 단위는 kB다.

참고: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 31. 표준 API와 /proc의 역할 분담

표준 API: uname·sysconf·getrlimit는 이식성 있는 근거다.

/proc: Linux의 진단·관찰 창이다. 더 많은 정보를 담는다.

선택 기준: 판단은 표준 API, 진단 스크립트는 /proc로.

같은 값을 두 창에서 확인하는 것이 오늘의 관점입니다.

교수자 메모: /proc/self/limits는 getrlimit가 주는 값과 같은 정보를 사람이 읽는 형태로 보여준다. 두 값이 어긋나 보이면 단위나 대상 프로세스를 먼저 확인한다.

참고: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 32. 실습 4: /proc 관찰

일치 확인: proc_probe 결과와 명령 출력을 줄 단위로 맞춘다.

fd 개수: 명령마다 개수가 조금씩 다른 이유를 설명한다.

limits: soft·hard가 getrlimit 결과와 같은지 본다.

```sh
./proc_probe

# 같은 정보를 명령으로 확인 (Linux)
grep -E 'VmRSS|Threads' /proc/self/status
cat /proc/loadavg
ls /proc/self/fd | wc -l
grep 'open files' /proc/self/limits

# 전체 요약은 선택
head -3 /proc/meminfo
```

값을 예측한 뒤 REPORT.md에 기록합니다.

교수자 메모: grep /proc/self/status의 self는 grep 프로세스 자신이다. 명령마다 프로세스가 다르므로 VmRSS와 fd 개수가 달라지는 것이 정상이고, 그 이유를 설명하는 것이 이 실습의 핵심이다.

참고: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 33. 확인 퀴즈

sysconf가 -1을 돌려줄 때 두 경우는 무엇이고 어떻게 구분하는가?

일반 사용자가 soft 한계와 hard 한계에서 바꿀 수 있는 범위는?

RLIMIT_NOFILE에 도달한 open의 errno 값은?

sysconf(_SC_OPEN_MAX)가 알려주는 값은 무엇과 같은가?

프로그램의 판단 근거로 /proc 대신 표준 API를 쓰는 이유는?

교수자 메모: 정답: 1. 조회 실패과 무한·미정의. 호출 전 errno를 0으로 만든 뒤 -1일 때 errno로 나눈다. 2. soft는 hard까지 상향 가능하고 hard 하향은 되돌릴 수 없다. 3. EMFILE. 4. RLIMIT_NOFILE의 soft 한계 값. 5. /proc는 Linux 고유이므로 이식성이 없다.

## 34. 실습 정리와 제출

sysprobe 결과를 uname·getconf 출력과 항목별로 비교한다.

limit_show의 soft·hard를 ulimit·/proc/self/limits와 비교한다.

nofile_demo로 EMFILE까지의 개수와 한계 변경 전후를 기록한다.

proc_probe 결과를 셸 명령 출력과 줄 단위로 대조한다.

C 소스, REPORT.md, 실행 로그를 제출한다.

선택 확장: sysprobe에 pathconf 항목 추가

교수자 메모: 필수 로그: uname 비교, soft·hard 값, EMFILE 개수, /proc 관찰. 선택 과제는 sysprobe에 pathconf(_PC_NAME_MAX) 항목을 추가하는 것이다.

## 35. 참고 자료

Linux man-pages: uname(2), sysinfo(2), getpagesize(2)

Linux man-pages: sysconf(3), pathconf(3), times(2)

Linux man-pages: getrlimit(2), open(2), signal(7)

Linux man-pages: proc(5)

수업은 Ubuntu 일반 사용자 환경을 기준으로 합니다.

교수자 메모: 각 슬라이드 발표자 노트와 교안 원고에 관련 원문 링크가 있다. 조회마다 대상, 반환값, 자료형, 실패 조건을 함께 확인한다.

참고: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html), [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html), [pathconf.3](https://man7.org/linux/man-pages/man3/pathconf.3.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html), [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html), [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [signal.7](https://man7.org/linux/man-pages/man7/signal.7.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html), [getpagesize.2](https://man7.org/linux/man-pages/man2/getpagesize.2.html)
