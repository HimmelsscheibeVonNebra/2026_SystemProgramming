# Week03-class01 · 복습과 파일 프로그램 4개

120분 수업, 슬라이드 37장. 지난 시간 복습을 독립된 섹션으로 구성했습니다.

1. 복습: C 컴파일, Makefile, 리다이렉션, 종료 상태
2. 파일 기초와 file_create: 바이트·메타데이터·경로·파일 종류, 빈 파일 생성, open/close
3. file_write: 덮어쓰기와 추가 기록, write
4. file_read: EOF까지 읽기, read
5. file_seek: 지정 위치를 읽고 수정, lseek

## 파일

- week03-class01.odp: Impress 편집용
- week03-class01.pdf: 열람·배포용
- week03-class01.md: 교안 원고와 교수자 메모
- labs/class03-01: C 프로그램 4개, io_helpers.h, Makefile, 실습 안내, 학생 기록지, 교수자 해설

본문 글꼴은 Noto Sans CJK KR, 코드는 Noto Sans Mono CJK KR입니다.
실습은 기존 Ubuntu 일반 사용자 환경을 사용하며 systemd는 필요 없습니다.
write_all은 완성 함수로 제공하고 다음 차시에 직접 구현합니다.

예제는 macOS에서 엄격한 경고 옵션으로 컴파일하고 정상·오류·바이트 단위 결과를 확인했습니다.
2026-09-14에 수업용 Linux 서버에서도 GCC 13.3.0으로 네 프로그램을 경고 없이 컴파일했습니다.
생성·덮어쓰기·추가·빈 파일·바이너리 읽기·권한 거부·쓰기 실패·잘못된 위치 입력·SEEK_END를 검증했고,
strace로 lseek/read/lseek/write/close 순서와 수정 결과 ABCXYFGHIJ(10바이트)를 확인했습니다.

## 참고 자료

- [open(2)](https://man7.org/linux/man-pages/man2/open.2.html)
- [close(2)](https://man7.org/linux/man-pages/man2/close.2.html)
- [read(2)](https://man7.org/linux/man-pages/man2/read.2.html)
- [write(2)](https://man7.org/linux/man-pages/man2/write.2.html)
- [lseek(2)](https://man7.org/linux/man-pages/man2/lseek.2.html)

슬라이드 발표자 노트에도 관련 출처를 넣었습니다. 표지는 기존 2주차 학교 시그니처를 사용했습니다.

## 디자인

`2026_SystemProgramming/Presentations/class02-01.odp`의 표지, 섹션, 제목 구분선, 코드 상자와 글꼴 스타일을 적용했습니다.
동일한 ODP를 해당 Presentations 폴더의 `class03-01.odp`에도 저장했습니다. PPTX는 배포 자료에서 제외했습니다.

파일 기초 설명은 2부 직후의 7–12번 슬라이드에 있습니다. 기존 바이트 예제를 옮기고 새 설명 5장을 추가했습니다.
