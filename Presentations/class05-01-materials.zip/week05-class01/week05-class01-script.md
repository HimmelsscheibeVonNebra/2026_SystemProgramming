# Week05-class01 수업 진행 대본

**시스템 정보와 자원 한계 · 교안 35장 · 120분(휴식 10분 포함)**

설명 멘트, 터미널 시연, 학생 예측과 실행, 확인 질문을 연결한 대본입니다. 시간은 수업 시작 후 누적 분이며 활동 시간을 포함합니다. 표준 API와 /proc 관찰 창의 구분을 중심으로 진행합니다.

## 수업 전 준비

- Ubuntu 일반 사용자 환경에서 cc, make, python3를 준비합니다.
- labs/class05-01에서 make와 make check를 실행합니다.
- sysprobe.c, limit_show.c, nofile_demo.c, proc_probe.c, sysinfo_demo.c를 엽니다.
- 실습 1부터 4까지 같은 터미널을 유지합니다.
- 값은 환경마다 다르므로 출력 숫자를 고정하지 않고 관계를 기록합니다.

```sh
cd labs/class05-01
make
make check
```

## 시간표

| 누적 시간 | 슬라이드 | 내용 |
|---|---|---|
| 00–10분 | 1–3 | 복습: 파일에서 실행 환경으로 |
| 10–30분 | 4–9 | uname·sysinfo, 실습 1 |
| 30–40분 | — | 휴식 |
| 40–65분 | 10–17 | sysconf·pathconf, 실습 2 |
| 65–95분 | 18–26 | getrlimit·setrlimit, 실습 3 |
| 95–115분 | 27–32 | /proc 관찰, 실습 4 |
| 115–120분 | 33–35 | 퀴즈와 제출 |

## 슬라이드 1 · 시스템 정보와 자원 한계

**00–02분 · 2분**

> 지난 두 주는 파일을 중심으로 다뤘습니다. 내용을 읽고 쓰는 저수준 입출력, 속성을 조회하는 stat 계열, 이름과 디렉토리를 다루는 호출을 배웠습니다. 오늘은 눈을 프로그램 자신으로 돌립니다. 내가 지금 어떤 시스템에서 돌고 있고, 어떤 자원까지 쓸 수 있는지를 프로그램이 스스로 알아내는 방법을 배웁니다.

**진행:** 표지를 보여 주고 오늘의 핵심 질문을 칠판에 적는다: 실행 환경은 누가 알려 주는가.

**확인 질문:** 프로그램이 자기 컴퓨터의 CPU 수를 알아야 할 상황을 떠올려 보세요.

**예상 답변:** 작업을 몇 개로 나눌지 정하거나, 서버가 감당할 동시 접속 수를 정할 때다.

교수자 참고: 지난 두 주는 파일의 내용·속성·이름을 다뤘다. 오늘은 프로그램이 자기 실행 환경을 알아내는 인터페이스를 다룬다. 표준 API와 Linux 관찰 창을 구분하는 것이 이번 시간의 핵심 문제다.

## 슬라이드 2 · 수업 구성

**02–04분 · 2분**

> 첫 시간에 시스템 식별을 다루고, 쉬는 뒤에 sysconf로 경계값을 조회합니다. 후반에는 프로세스별 자원 한계를 다루고 마지막에 /proc로 리눅스의 상태를 직접 관찰합니다. 표준 API와 리눅스 고유의 관찰 창을 구분하는 것이 오늘의 큰 그림입니다.

**진행:** 학생이 labs/class05-01에서 make를 실행했는지 확인한다. REPORT.md를 열도록 한다.

**확인 질문:** 오늘 배우는 호출 중 프로그램을 기다리게 만드는 호출이 있을까요?

**예상 답변:** 없다. 오늘은 모두 즉시 답을 주는 조회 호출이다. 반환값 검사가 전부다.

교수자 참고: 1부를 마친 뒤 휴식 10분을 포함해 총 120분이다. 전반부는 실행 환경을 알아내는 조회 API의 계약을, 후반부는 자원 한계와 /proc 관찰을 다룬다.

## 슬라이드 3 · 왜 시스템 정보를 읽는가

**04–09분 · 5분**

> 같은 프로그램도 환경에 따라 조건이 달라집니다. 페이지 크기, CPU 수, 열린 파일 상한을 상수로 가정하면 다른 컴퓨터에서 실패합니다. 오류 로그에 시스템 정보를 남기면 나중에 원인을 좁히기 쉽습니다. 2주차에 uname과 sysconf 예제를 잠깐 실행했지만 그때는 출력만 보았습니다. 오늘은 반환값 계약까지 다룹니다.

**진행:** 2주차의 system_info 예제를 1분간 떠올리게 한다. 오류 로그에 어떤 식별 정보가 있으면 좋을지 2분간 짝과 정리한다.

**확인 질문:** 버그 보고서에 uname -a 결과를 첨부하면 무엇이 좋아지나요?

**예상 답변:** 같은 커널과 아키텍처에서 재현했는지 확인할 수 있다.

교수자 참고: 같은 프로그램도 실행 환경에 따라 동작 조건이 달라진다. 페이지 크기, CPU 수, 열린 파일 상한을 상수로 가정하면 다른 환경에서 실패한다. 오늘 배우는 호출은 모두 값을 얻는 조회이며, 반환값 검사가 곧 프로그램의 첫 단계다.

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 슬라이드 4 · 1부 시스템 식별

**09–10분 · 1분**

> 첫 부분은 시스템을 식별하는 API입니다. 누가, 어느 커널에서, 어떤 아키텍처로 돌고 있는지를 문자열로 얻습니다.

**진행:** uname이라는 이름이 유닉스의 what 시스템에서 왔다는 점은 덧붙이지 않아도 된다.

**확인 질문:** 식별 정보에 파일 크기 같은 값도 들어가나요?

**예상 답변:** 아니다. 식별은 시스템 전체의 정체지 이름·버전·아키텍처다.

## 슬라이드 5 · uname(2)과 struct utsname

**10–14분 · 4분**

> utsname 구조체는 다섯 개의 문자열 배열로 이루어져 있습니다. sysname은 커널 이름, nodename은 호스트 이름, release와 version은 커널 버전 문자열, machine은 아키텍처입니다. 함수 uname은 이 구조체를 채우고 성공 0, 실패 -1을 돌려줍니다.

**진행:** 각 필드를 칠판에 적고 학생이 자기 노트북의 예상 값을 적게 한다. version 문자열은 형식이 정해져 있지 않음을 보여 준다.

**확인 질문:** nodename은 항상 hostname 명령과 같을까요?

**예상 답변:** 보통 같지만 컨테이너처럼 다르게 보이는 환경도 있다.

교수자 참고: 헤더는 <sys/utsname.h>이고 성공 0, 실패 -1이다. version 문자열의 형식은 배포판마다 다르다. domainname 필드는 Linux 확장이다. nodename이 항상 호스트 이름과 일치하지는 않는다(컨테이너 등).

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 슬라이드 6 · sysprobe: uname 조회

**14–18분 · 4분**

> sysprobe의 앞부분입니다. uname을 호출해 구조체를 채우고 성공한 뒤에만 필드를 출력합니다. 실패하면 perror로 errno 메시지를 남기고 종료 상태 1로 끝냅니다. 우리가 반복해 온 조회 뒤 출력 순서 그대로입니다.

**진행:** sysprobe.c의 uname 블록을 같이 읽는다. 뒤에 이어지는 sysconf 부분은 2부에서 다시 연다.

**확인 질문:** uname 실패 뒤에 구조체 필드를 읽으면 어떻게 되나요?

**예상 답변:** 이번 결과가 아니므로 쓰레기 값일 수 있다. 읽지 않는다.

교수자 참고: sysname 값으로 운영 체제를 구분하는 코드를 만들 수 있다. 완성 sysprobe는 버전 필드와 sysconf 결과까지 함께 출력한다.

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 슬라이드 7 · uname(1) 명령과 비교

**18–21분 · 3분**

> 셸의 uname 명령은 같은 정보를 사람이 읽는 형태로 보여 줍니다. uname -a는 전부를 한 줄로, -r은 릴리스만, -m은 아키텍처만 출력합니다. 프로그램이 uname(2)으로 얻는 값과 명령의 열이 어떻게 대응하는지 오늘 실습에서 맞춰 봅니다.

**진행:** uname -a를 실행하고 그 줄을 슬라이드의 sysprobe 출력과 나란히 비교한다. macOS 학생은 Darwin 출력도 함께 본다.

**확인 질문:** uname -m과 sysprobe의 machine이 다르게 나올 수 있나요?

**예상 답변:** 같은 정보를 다르게 표기하는 경우는 드물지만 version 문자열은 배포판마다 다르다.

교수자 참고: 화면의 출력은 Ubuntu 예시다. macOS에서는 sysname이 Darwin이고 machine이 arm64처럼 나온다. 값 자체보다 어떤 필드가 어느 열에 대응하는지가 중요하다.

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html)

## 슬라이드 8 · sysinfo(2): 자원 요약

**21–24분 · 3분**

> sysinfo는 uptime, 부하 평균, 전체와 가용 램, 프로세스 수를 한 번의 호출로 줍니다. 램 필드는 mem_unit을 곱해 바이트로 환산합니다. 이 호출은 리눅스 전용입니다. 그래서 예제 소스는 조건부 컴파일로 리눅스가 아니면 안내 문장을 출력하게 작성했습니다. 이식성과 플랫폼 확장을 코드로 구분하는 첫 예시입니다.

**진행:** sysinfo_demo.c의 #ifdef __linux__ 블록을 보여 준다. macOS에서 실행하면 Linux-only 문장이 나오는 것을 미리 예측하게 한다.

**확인 질문:** 같은 정보를 표준 API로도 얻을 수 있나요?

**예상 답변:** 부분적으로 가능하지만 sysinfo의 묶음 그대로는 없다. 그래서 전용으로 분류한다.

교수자 참고: loads는 65536을 1로 하는 고정소수점 값이다. 같은 정보를 /proc/meminfo와 /proc/loadavg에서도 읽을 수 있다. sysinfo_demo는 Linux가 아니면 안내 문장을 출력하고 실패 상태로 끝난다.

원문: [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html)

## 슬라이드 9 · 실습 1: 시스템 식별 관찰

**24–30분 · 6분**

> 첫 실습입니다. sysprobe를 실행하고 uname 명령의 각 옵션과 출력을 표로 맞춥니다. strace로 uname 시스템 호출이 실제로 일어나는지 확인합니다. 리눅스에서는 sysinfo_demo까지 실행하고, macOS 실습 환경에서는 Linux 전용 안내가 나오는 것도 관찰로 기록합니다.

**진행:** 5분간 실행과 기록, 1분간 짝과 비교한다. REPORT.md의 1번 표를 채우게 한다.

**확인 질문:** strace 출력에서 uname을 못 찾으면 어떻게 하나요?

**예상 답변:** 라이브러리가 캐시했을 수 있다. -e 옵션 접두사와 아키텍처별 시스템 호출 이름을 확인한다.

```sh
./sysprobe
uname -a
uname -r
uname -m

# Ubuntu에서 시스템 호출 관찰
strace -e uname ./sysprobe

# Linux에서만 동작
./sysinfo_demo
```

교수자 참고: sysprobe의 각 줄이 uname의 어느 옵션과 같은지 표로 적는다. macOS 실습 환경에서는 sysinfo_demo가 Linux 전용 안내를 출력하는 것도 관찰 결과다.

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html)

## 휴식 · 30–40분

같은 터미널을 유지하고 휴식 후 sysconf 실습으로 이어갑니다.

## 슬라이드 10 · 2부 sysconf와 경계값

**40–41분 · 1분**

> 두 번째 부분은 경계값입니다. 페이지 크기, CPU 수, clock tick처럼 시스템마다 다른 숫자를 실행 시점에 얻어 옵니다.

**진행:** 부제를 읽고 컴파일 시점 상수와 실행 시점 조회의 차이를 한 문장으로 정리하게 한다.

**확인 질문:** 헤더 파일에 정의된 PAGE_SIZE 상수를 쓰면 안 되나요?

**예상 답변:** 그 상수는 빌드 대상을 가정한 값이다. 실행 환경이 다르면 틀린다.

## 슬라이드 11 · sysconf(3)의 역할

**41–44분 · 3분**

> sysconf는 조회할 항목을 _SC_ 상수로 고르고 long을 돌려줍니다. 헤더는 unistd.h입니다. 단순해 보이지만 반환값에 함정이 있습니다. 그 함정이 다음 슬라이드의 핵심입니다.

**진행:** _SC_PAGESIZE와 _SC_NPROCESSORS_ONLN을 칠판에 적고 학생이 예상 값을 말하게 한다.

**확인 질문:** sysconf는 왜 인자를 숫자가 아니라 상수 이름으로 받을까요?

**예상 답변:** 조회 항목이 컴파일 시점에 정해지기 때문이다. 문자열 비교가 필요 없다.

교수자 참고: 헤더는 <unistd.h>다. 조회마다 값이 다를 수 있으므로 결과를 저장해 재사용하는 코드와 매번 조회하는 코드의 차이를 생각해 본다.

원문: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 슬라이드 12 · sysconf의 반환값 계약

**44–48분 · 4분**

> sysconf는 실패해도 errno를 바꾸지 않을 수 있습니다. 그래서 -1은 두 가지 뜻을 가질 수 있습니다. 하나는 조회가 실패한 경우, 다른 하나는 한계 자체가 없거나 값을 정할 수 없는 경우입니다. 구분하는 방법은 호출 직전에 errno를 0으로 만들어 두는 것입니다. -1이 돌아왔을 때 errno가 0이면 무한 또는 미정의, 0이 아니면 실패입니다.

**진행:** 이 순서를 칠판에 크게 적는다: errno=0, 호출, -1이면 errno 확인. 2분간 학생이 말로 다시 설명하게 한다.

**확인 질문:** 왜 호출 전에 errno를 0으로 만들어야 하나요?

**예상 답변:** 실패해도 errno를 안 바꿀 수 있어서 이전 호출의 값이 남아 있기 때문이다.

교수자 참고: sysconf는 실패해도 errno를 바꾸지 않을 수 있다. 그래서 호출 전에 errno를 0으로 초기화하는 관습이 필요하다. 지원하지 않는 name은 EINVAL으로 실패한다. 이 읽기법은 -1과 errno의 조합으로 상태를 나누는 대표 사례다.

원문: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 슬라이드 13 · 자주 쓰는 _SC 상수

**48–52분 · 4분**

> 자주 만나는 네 개 상수입니다. PAGESIZE는 메모리 최소 단위, NPROCESSORS_ONLN은 지금 쓸 수 있는 CPU 수, CLK_TCK는 times가 돌려주는 틱의 초당 개수입니다. OPEN_MAX는 열린 파일 상한, ARG_MAX는 exec 인자와 환경의 총 크기입니다. x86_64 리눅스에서 4096과 100이 흔한 값이지만 이 숫자를 코드에 박지 않습니다.

**진행:** 각 상수가 어디서 쓰일지 한 줄씩 짝과 연결하게 한다. OPEN_MAX는 3부의 FD 한계와 이어진다고 예고한다.

**확인 질문:** CLK_TCK가 100이라는 건 무엇이 0.01초라는 뜻인가요?

**예상 답변:** times의 틱 하나가 0.01초라는 뜻이다. CPU 시간을 초로 바꿀 때 나눈다.

교수자 참고: _SC_OPEN_MAX는 FD의 soft 한계 값이고 _SC_ARG_MAX는 exec 인자와 환경의 총 크기 상한이다. x86_64 Linux에서 PAGESIZE 4096, CLK_TCK 100이 흔하지만 코드에 박아 넣지 않고 조회해 쓴다.

원문: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html)

## 슬라이드 14 · sysprobe: sysconf 읽기

**52–56분 · 4분**

> probe 함수가 방금 계약을 그대로 구현합니다. 호출 직전 errno를 0으로 만들고, -1이면 errno로 두 갈래를 나눕니다. 라벨을 인자로 받아 오류 메시지가 어느 조회에서 났는지 알려 줍니다. 완성 sysprobe는 이 함수로 다섯 값을 모두 출력합니다.

**진행:** probe 함수를 같이 읽으며 return 1과 return 0이 각각 무엇을 알리는지 묻는다. sysprobe를 다시 실행해 출력을 확인한다.

**확인 질문:** probe가 -1과 errno 0을 만나면 무엇을 출력하나요?

**예상 답변:** unlimited를 출력하고 실패로 세지 않는다.

교수자 참고: 완성 sysprobe는 cpus_online, pagesize, clk_tck, open_max, arg_max를 이 함수로 출력한다. 라벨을 인자로 받으면 오류 메시지가 어느 조회인지 알려준다.

원문: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 슬라이드 15 · 페이지 크기와 CLK_TCK가 쓰이는 곳

**56–59분 · 3분**

> 페이지 크기는 11주 mmap에서 다시 만납니다. 오늘은 그 값이 시스템마다 다르다는 것과 조회해서 쓴다는 원칙만 가져갑니다. CLK_TCK는 다음 시간에 배울 시간 처리에서 times와 짝으로 쓰입니다. CPU 수는 작업 분배의 근거가 됩니다. Apple 실리콘은 16384바이트 페이지를 씁니다. 같은 프로그램으로 이 차이를 관찰하는 것도 과제입니다.

**진행:** sysprobe를 두 환경에서 실행한 결과를 나란히 보여 준다(준비된 경우). 값의 차이를 코드가 아니라 환경이 만든다는 점을 강조한다.

**확인 질문:** 페이지 크기를 모르고 버퍼를 정하면 어떤 문제가 생기나요?

**예상 답변:** 정렬이 어긋나거나 낭비가 생긴다. mmap에서는 계산 자체가 틀어질 수 있다.

교수자 참고: Apple Silicon은 16384바이트 페이지를 쓴다. sysconf(_SC_PAGESIZE)는 getpagesize()보다 표준적인 방법이다. CLK_TCK는 다음 시간에 배울 시간 처리에서 times와 짝으로 쓰인다.

원문: [getpagesize.2](https://man7.org/linux/man-pages/man2/getpagesize.2.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html)

## 슬라이드 16 · pathconf와 fpathconf

**59–61분 · 2분**

> pathconf와 fpathconf는 파일시스템에 따라 달라지는 경계값을 묻습니다. NAME_MAX는 그 디렉토리에서 파일 이름의 최대 길이, PATH_MAX는 경로의 최대 길이입니다. pathconf는 경로를, fpathconf는 열린 FD를 기준으로 삼습니다. 반환값 계약은 sysconf와 같습니다. 지난 주 디렉토리 순회 코드에서 긴 이름을 다룰 때 이 값이 기준이 됩니다.

**진행:** 서로 다른 파일시스템에서 NAME_MAX가 다를 수 있음을 질문으로 확인한다. 열린 FD 기준이 왜 유용한지(경로가 바뀌어도 안전)를 덧붙인다.

**확인 질문:** 왜 NAME_MAX를 파일이 아니라 디렉토리 기준으로 묻나요?

**예상 답변:** 이름의 길이 제한은 이름이 속한 파일시스템이 정하기 때문이다.

교수자 참고: pathconf는 경로를, fpathconf는 열린 FD를 기준으로 삼는다. 반환값 계약은 sysconf와 같다. Linux의 PATH_MAX 제한은 실제로는 더 긴 경로도 다루는 경우가 있어 문서를 함께 읽는다.

원문: [pathconf.3](https://man7.org/linux/man-pages/man3/pathconf.3.html)

## 슬라이드 17 · 실습 2: 경계값 비교

**61–65분 · 4분**

> 두 번째 실습입니다. sysprobe의 값과 getconf 명령의 출력을 맞추고 ulimit -Sn으로 FD의 soft 한계도 확인합니다. 같은 값을 서로 다른 문에서 두 번 확인하는 습관이 오늘의 반복 동작입니다.

**진행:** 4분간 실행과 기록, 1분간 어긋난 항목이 있는지 짝과 비교한다. macOS에서는 getconf 일부 값이 다름을 미리 안내한다.

**확인 질문:** getconf OPEN_MAX와 ulimit -Sn이 다르게 나오면 무엇을 의심하나요?

**예상 답변:** 조회 시점의 soft 한계가 다른 것이다. 셸 설정이나 시스템 설정 차이를 확인한다.

```sh
./sysprobe

# 같은 값을 셸에서 확인 (Linux)
getconf PAGE_SIZE
getconf CLK_TCK
getconf NPROCESSORS_ONLN
getconf OPEN_MAX

# FD 한계는 3부에서 다룬다
ulimit -Sn
```

교수자 참고: getconf OPEN_MAX와 ulimit -Sn이 같은 숫자인지, sysprobe의 open_max와도 같은지 비교한다. macOS에서는 일부 기본값이 달라진다. 값이 다르다면 그 이유를 문서에서 찾는다.

원문: [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html)

## 슬라이드 18 · 3부 자원 한계

**65–66분 · 1분**

> 세 번째 부분은 자원 한계입니다. 조회에서 한 걸음 나아가 값을 읽고 조건 안에서 바꿉니다.

**진행:** limit_show를 미리 실행해 두고 출력을 보여 준다.

**확인 질문:** 한계라는 게 무엇을 막는 건가요?

**예상 답변:** 프로세스가 쓸 수 있는 자원의 양을 넘지 못하게 하는 커널의 상한이다.

## 슬라이드 19 · getrlimit과 setrlimit

**66–70분 · 4분**

> rlimit 구조체는 두 값입니다. rlim_cur가 지금 강제되는 soft 한계, rlim_max가 soft가 올라갈 수 있는 상한인 hard 한계입니다. getrlimit는 현재 값을 구조체로 돌려주고, setrlimit는 조건을 만족할 때만 바꿉니다. 거부되면 -1과 EPERM입니다. 구조체를 채운 뒤에만 필드를 읽는 규칙은 stat과 같습니다.

**진행:** soft와 hard를 두 줄로 칠판에 적는다. limit_show 출력의 두 열이 이 두 값임을 연결한다.

**확인 질문:** getrlimit는 실패할 수도 있나요?

**예상 답변:** 드물지만 인자 오류 등으로 실패할 수 있다. 반환값 검사는 그대로 한다.

교수자 참고: 헤더는 <sys/resource.h>다. 구조체를 채운 뒤에야 필드를 읽는 규칙은 stat과 같다. 값을 바꾼 뒤에는 getrlimit로 실제 값을 다시 확인한다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 20 · soft 한계와 hard 한계

**70–74분 · 4분**

> soft는 지금 강제되는 값이고 hard는 상한입니다. 일반 사용자는 soft를 hard까지 올릴 수 있습니다. hard를 낮추는 것은 되돌릴 수 없습니다. 되돌리려면 특권이 필요하기 때문입니다. RLIM_INFINITY는 무제한을 뜻하는 특별한 값입니다. 셸에서 ulimit -n처럼 -S를 붙이지 않으면 soft와 hard를 함께 바꾸므로 실습에서는 ulimit -Sn을 씁니다.

**진행:** 실습에서 왜 -Sn만 쓰는지 이 슬라이드에서 분명히 한다. 프로그램이 바꾼 한계는 부모 셸에 영향을 주지 않음을 반복한다.

**확인 질문:** hard를 실수로 낮추면 어떻게 되나요?

**예상 답변:** 그 셸 안에서는 되돌릴 수 없다. 새 셸을 열어야 한다.

교수자 참고: hard를 올리는 것은 보통 특권이 필요하다. bash의 ulimit -n은 -S를 붙이지 않으면 soft와 hard를 함께 바꾸므로 실습에서는 ulimit -Sn을 쓴다. 프로그램이 바꾼 한계는 그 프로세스와 이후 자식에만 적용된다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 21 · 주요 RLIMIT 종류

**74–77분 · 3분**

> 대표적인 다섯 종류입니다. NOFILE은 열린 파일 개수, FSIZE는 파일 크기, CPU는 CPU 시간, AS는 주소 공간, STACK은 스택 크기, NPROC는 사용자 프로세스 수의 상한입니다. 리눅스의 NPROC는 실제 사용자 ID별로 계산합니다. 세부 의미는 getrlimit(2)의 표에서 확인합니다.

**진행:** limit_show의 일곱 줄이 어느 RLIMIT인지 하나씩 대응시킨다. core 덤프 상한도 보인다.

**확인 질문:** AS 한계에 걸리면 어떤 호출이 실패하나요?

**예상 답변:** mmap이나 큰 메모리 할당이 ENOMEM으로 실패할 수 있다.

교수자 참고: Linux의 RLIMIT_NPROC는 실제 사용자 ID별로 계산한다. RLIMIT_CORE는 코어 덤프 크기 상한으로 limit_show가 함께 출력한다. 세부 의미는 getrlimit(2)의 표로 확인한다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 22 · limit_show: getrlimit 출력

**77–81분 · 4분**

> limit_show의 핵심입니다. getrlimit로 구조체를 얻고 무한 값은 RLIM_INFINITY와 비교해 unlimited로 표시합니다. rlim_t의 크기가 시스템마다 다를 수 있어 uintmax_t로 변환해 %ju로 출력합니다. 정수형을 printf 형식에 맞추는 패턴은 지난 주에도 반복했습니다.

**진행:** %ju와 rlim_t의 관계를 1분간 설명한다. 무한 값이 어떤 비트 패턴인지는 다루지 않고 비교로만 다룬다.

**확인 질문:** soft가 무한이고 hard가 유한할 수 있나요?

**예상 답변:** soft는 hard보다 클 수 없으므로 그 조합은 일반적으로 나오지 않는다.

교수자 참고: rlim_t의 크기는 시스템마다 다를 수 있어 printf 형식을 맞추기 위해 uintmax_t로 변환한다. 완성 limit_show는 일곱 종류의 자원을 출력한다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 23 · 한계에 도달하면 무슨 일이 생기나

**81–84분 · 3분**

> 한계에 닿으면 두 형태의 결과가 있습니다. FD 개수를 넘으면 open이 -1과 EMFILE입니다. 파일 크기를 넘으면 write가 EFBIG이고 SIGXFSZ가 갈 수 있습니다. CPU 시간을 넘으면 SIGXCPU가 먼저 옵니다. 오류 반환으로 나타나는 경우를 오늘 직접 관찰하고, 시그널 처리는 9주차에서 다룹니다.

**진행:** EMFILE만 오늘 확인 목표임을 분명히 한다. SIGXCPU와 SIGXFSZ 이름만 소개한다.

**확인 질문:** 왜 어떤 초과는 시그널이고 어떤 초과는 오류 반환일까요?

**예상 답변:** 진행 중인 작업을 끊어야 하는지, 시작을 막으면 되는지에 따라 다르다.

교수자 참고: 시그널을 다루는 방법은 9주차 주제다. 오늘은 한계 초과가 호출 실패로 나타나는 경우를 직접 관찰한다. 기본 시그널 처리로 끝나는 경우도 있다는 것만 알아 둔다.

원문: [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [signal.7](https://man7.org/linux/man-pages/man7/signal.7.html)

## 슬라이드 24 · nofile_demo: FD 한계 실험

**84–88분 · 4분**

> nofile_demo는 FD 한계를 직접 밟아 보는 실험입니다. /dev/null을 열 수 있을 때까지 open을 반복하고 EMFILE를 만나면 멈춥니다. 표준 입출력 오류 FD 세 개가 이미 열려 있으므로 opened는 soft보다 약간 작습니다. 실험이 끝나면 연 FD를 모두 닫습니다.

**진행:** 배열 크기를 soft에 맞춰 잡는 부분과 실패 경로에서도 닫는 부분을 찾게 한다.

**확인 질문:** EMFILE을 만나면 프로그램은 무조건 죽어야 하나요?

**예상 답변:** 아니다. 상황에 따라 기존 FD를 닫고 다시 시도할 수도 있다. 오늘은 관찰이 목적이다.

교수자 참고: 표준 입출력 오류 FD 세 개가 이미 열려 있으므로 opened는 soft 값보다 약간 작다. 배열 크기는 soft 한계에 맞춰 확보한다. 실패해도 연 FD는 모두 닫는다.

원문: [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 25 · setrlimit로 soft 한계 바꾸기

**88–91분 · 3분**

> setrlimit는 soft 한계를 바꿉니다. 먼저 getrlimit로 hard를 읽고, 요청이 hard를 넘으면 hard로 제한합니다. 일반 사용자는 hard를 넘어 올릴 수 없기 때문입니다. 바꾼 뒤에는 getrlimit로 실제 값을 다시 읽어 출력합니다. 프로그램이 바꾼 한계는 이 프로세스와 이후 자식에만 적용됩니다. 부모 셸은 그대로입니다.

**진행:** 변경-재조회 순서를 강조한다. 셸의 ulimit -Sn이 같은 역할임을 연결한다.

**확인 질문:** 이 프로그램이 FD 한계를 올려도 내 셸에는 왜 영향이 없나요?

**예상 답변:** 프로세스별 속성이고 부모로 전파되지 않기 때문이다.

교수자 참고: 셸에서는 ulimit -Sn N이 같은 역할을 한다. 프로그램이 바꾼 한계는 부모 셸에 영향을 주지 않는다. hard를 넘는 상향 시도가 조용히 hard로 잘리는 것은 이 예제의 동작이고, 셸에서는 허용 오류로 나타난다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 26 · 실습 3: FD 한계 관찰

**91–95분 · 4분**

> 세 번째 실습입니다. 기본 상태에서 nofile_demo를 실행하고, --raise로 soft를 64와 4096으로 바꿔 비교합니다. 새 bash 안에서 ulimit -Sn을 바꾸고 실행하는 실험도 합니다. 환경에 따라 기본 soft가 이미 클 수 있는데 그럴 때는 64가 하향 실험이 됩니다. 변화의 방향보다 측정 값이 soft를 따라가는지가 중요합니다.

**진행:** 4분간 세 가지 실행을 기록한다. 1분간 opened 값이 왜 soft와 정확히 같지 않은지 짝과 정리한다.

**확인 질문:** opened가 soft보다 정확히 3만큼 작지 않은 이유는 무엇일까요?

**예상 답변:** 셸이나 라이브러리가 이미 연 FD가 더 있을 수 있다. 근처 값이면 된다.

```sh
./limit_show | head -1
./nofile_demo
./nofile_demo --raise 64
./nofile_demo --raise 4096

# 셸에서 soft만 바꿔 비교 (hard 이하)
bash -c 'ulimit -Sn 64 && ./nofile_demo'
bash -c 'ulimit -Sn 4096; ./nofile_demo'
```

교수자 참고: 환경에 따라 기본 soft가 이미 클 수 있다. 그럴 때 --raise 64는 하향 실험이 된다. 4096이 hard보다 크면 hard 값으로 잘리는 것도 관찰한다. 셸 실험은 새 bash 안에서만 한계가 바뀌는지 확인하는 것이 목적이다.

원문: [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 27 · 4부 /proc 관찰 창

**95–96분 · 1분**

> 마지막 부분은 /proc입니다. 표준 API 바깥에서 리눅스의 상태를 파일처럼 읽는 방법입니다.

**진행:** ls /proc를 실행해 파일과 숫자 디렉토리가 섞여 있는 모습을 보여 준다.

**확인 질문:** /proc 안의 숫자 디렉토리는 무엇을 가리킬까요?

**예상 답변:** 각 숫자는 프로세스 ID이고 그 안이 프로세스 정보다.

## 슬라이드 28 · /proc 파일시스템

**96–99분 · 3분**

> /proc는 커널과 프로세스 상태를 파일처럼 보여 주는 가상 파일시스템입니다. 읽을 때마다 커널이 그 순간의 상태를 만들어 줍니다. 표준이 아니라 리눅스 고유의 관찰 창입니다. 그래서 프로그램의 판단 근거보다 진단과 스크립트에 쓰는 것이 원칙입니다. 지난 주에 배운 opendir과 fgets 조합으로 그대로 읽을 수 있습니다.

**진행:** cat /proc/loadavg를 실행해 한 줄이 어떻게 만들어지는지 보여 준다. 파일 크기가 0으로 보여도 내용이 있음을 시연한다.

**확인 질문:** /proc의 파일은 어디에 저장되어 있나요?

**예상 답변:** 디스크가 아니라 커널이 읽는 순간 만들어 주는 값이다.

교수자 참고: /proc의 파일 크기는 보통 0으로 표시되지만 내용은 있다. 다른 Unix에도 비슷한 메커니즘이 있으나 구조가 다르다. 이식성이 필요한 판단은 표준 API로, 진단은 /proc로 나누는 것이 오늘의 원칙이다.

원문: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 슬라이드 29 · /proc의 주요 경로

**99–103분 · 4분**

> 주요 경로 네 가지입니다. cpuinfo와 meminfo는 전체 요약, loadavg는 부하 평균 한 줄, self 아래는 이 프로세스 자신의 상태·한계·열린 FD입니다. self는 실행 중인 프로세스로 풀리고, 숫자 PID를 쓰면 다른 프로세스를 관찰할 수도 있습니다.

**진행:** /proc/self/fd를 ls로 보여 주고 항목이 FD 번호 이름의 심볼릭 링크임을 확인한다.

**확인 질문:** /proc/self/limits와 limit_show는 어떤 관계인가요?

**예상 답변:** 같은 정보를 사람이 읽는 형태와 프로그램이 읽는 형태로 보여 준다.

교수자 참고: self는 실행 중인 프로세스 자신으로 풀린다. /proc/self/fd의 항목은 FD 번호 이름의 심볼릭 링크다. pid를 직접 쓰면 다른 프로세스도 관찰할 수 있다.

원문: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 슬라이드 30 · proc_probe: /proc/self 관찰

**103–107분 · 4분**

> proc_probe는 /proc/self/status를 열어 VmRSS와 Threads 줄만 걸러 출력합니다. 3주차에 배운 stdio 함수로 일반 파일처럼 읽습니다. loadavg 첫 줄도 읽고, /proc/self/fd를 opendir로 세어 개수를 출력합니다. 주의할 점이 하나 있습니다. /proc/self/fd를 여는 순간 그 스트림 자체가 FD 하나를 추가합니다.

**진행:** 완성 소스에서 필터 조건과 opendir 반복문을 찾게 한다. macOS 실습 환경에서는 안내 오류가 나오는 것까지 관찰로 기록한다.

**확인 질문:** VmRSS의 단위는 무엇인가요?

**예상 답변:** kB다. proc(5)의 필드 설명에 단위가 있다.

교수자 참고: 완성 proc_probe는 loadavg 첫 줄과 fd 개수도 출력한다. /proc/self/fd를 여는 순간 그 스트림 자체가 FD 하나를 추가하므로 개수 해석에 주의한다. VmRSS의 단위는 kB다.

원문: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 슬라이드 31 · 표준 API와 /proc의 역할 분담

**107–110분 · 3분**

> 오늘의 큰 그림을 정리하는 슬라이드입니다. 판단의 근거는 표준 API에서, 진단과 관찰은 /proc에서 얻습니다. /proc/self/limits는 getrlimit와 같은 값을 사람이 읽는 형태로 보여 줍니다. 두 창이 어긋나 보이면 단위나 대상 프로세스를 먼저 확인합니다.

**진행:** 학생에게 오늘 배운 호출을 표준과 리눅스 전용 두 상자로 나누어 적게 한다.

**확인 질문:** 이식성이 필요 없는 회사 내부 진단 스크립트라면 어느 쪽을 써도 될까요?

**예상 답변:** 목적이 진단이라면 /proc도 합리적인 선택이다. 기준은 이식성 필요 여부다.

교수자 참고: /proc/self/limits는 getrlimit가 주는 값과 같은 정보를 사람이 읽는 형태로 보여준다. 두 값이 어긋나 보이면 단위나 대상 프로세스를 먼저 확인한다.

원문: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

## 슬라이드 32 · 실습 4: /proc 관찰

**110–115분 · 5분**

> 마지막 실습입니다. proc_probe 결과를 셸 명령의 출력과 줄 단위로 맞춥니다. grep /proc/self/status의 self는 grep 프로세스 자신입니다. 명령마다 프로세스가 다르므로 VmRSS와 fd 개수가 조금씩 다른 것이 정상이고, 그 이유를 설명하는 것이 이 실습의 핵심입니다.

**진행:** 3분간 실행과 기록, 2분간 왜 값이 다른지 짝과 설명한다. /proc/self/limits의 open files 줄을 limit_show와 맞추게 한다.

**확인 질문:** 같은 명령을 두 번 실행했는데 fd 개수가 다른 이유는 무엇인가요?

**예상 답변:** 프로세스가 다르고 실행 순간의 상태가 다르기 때문이다.

```sh
./proc_probe

# 같은 정보를 명령으로 확인 (Linux)
grep -E 'VmRSS|Threads' /proc/self/status
cat /proc/loadavg
ls /proc/self/fd | wc -l
grep 'open files' /proc/self/limits

# 전체 요약은 선택
head -3 /proc/meminfo
```

교수자 참고: grep /proc/self/status의 self는 grep 프로세스 자신이다. 명령마다 프로세스가 다르므로 VmRSS와 fd 개수가 달라지는 것이 정상이고, 그 이유를 설명하는 것이 이 실습의 핵심이다.

원문: [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html)

## 슬라이드 33 · 확인 퀴즈

**115–117분 · 2분**

> 다섯 확인 문제로 정리합니다. 답만 말하지 말고 어떤 계약 때문에 그 답이 나오는지 함께 설명해 주세요.

**진행:** 1분간 개인 답안 작성, 2분간 정답 근거 확인.

**확인 질문:** 정답의 핵심을 한 문장씩 말해 보세요.

**예상 답변:** -1의 두 의미와 errno 초기화, soft는 hard까지, EMFILE, soft 한계와 같은 값, 이식성이다.

교수자 참고: 정답: 1. 조회 실패과 무한·미정의. 호출 전 errno를 0으로 만든 뒤 -1일 때 errno로 나눈다. 2. soft는 hard까지 상향 가능하고 hard 하향은 되돌릴 수 없다. 3. EMFILE. 4. RLIMIT_NOFILE의 soft 한계 값. 5. /proc는 Linux 고유이므로 이식성이 없다.

## 슬라이드 34 · 실습 정리와 제출

**117–119분 · 2분**

> 제출물은 소스와 실행 로그, REPORT.md입니다. 값 자체가 환경마다 다른 것이 오늘 자료의 성격입니다. 그래서 채점 기준은 숫자 일치가 아니라 두 문에서 같은 값을 얻었는지, 변화의 방향을 설명했는지입니다. 선택 과제는 sysprobe에 pathconf 항목을 추가하는 것입니다.

**진행:** REPORT 양식과 제출 파일을 보여 준다. 마감과 배점은 수업 운영에 맞게 별도 안내한다.

**확인 질문:** REPORT에 왜 두 문으로 확인한 값을 적게 하나요?

**예상 답변:** 한 문에서만 나오는 값은 환경 특수성일 수 있어서다. 교차 확인이 근거가 된다.

교수자 참고: 필수 로그: uname 비교, soft·hard 값, EMFILE 개수, /proc 관찰. 선택 과제는 sysprobe에 pathconf(_PC_NAME_MAX) 항목을 추가하는 것이다.

## 슬라이드 35 · 참고 자료

**119–120분 · 1분**

> 새 API를 읽을 때는 반환값과 오류 표시 방식부터 확인하세요. 오늘처럼 하나의 값으로 두 상태를 표현하는 API는 초기화 순서가 계약의 일부입니다. 관련 원문은 교안과 발표자 노트에 연결했습니다.

**진행:** man 3 sysconf, man 2 getrlimit처럼 절 번호를 포함한 조회를 안내하고 수업을 마무리한다.

**확인 질문:** 오늘 배운 조회 호출에 공통으로 들어 있는 패턴은 무엇인가요?

**예상 답변:** 성공과 실패의 반환값, 그리고 실패 원인을 errno로 확인하는 계약이다.

교수자 참고: 각 슬라이드 발표자 노트와 교안 원고에 관련 원문 링크가 있다. 조회마다 대상, 반환값, 자료형, 실패 조건을 함께 확인한다.

원문: [uname.2](https://man7.org/linux/man-pages/man2/uname.2.html), [sysinfo.2](https://man7.org/linux/man-pages/man2/sysinfo.2.html), [sysconf.3](https://man7.org/linux/man-pages/man3/sysconf.3.html), [pathconf.3](https://man7.org/linux/man-pages/man3/pathconf.3.html), [getrlimit.2](https://man7.org/linux/man-pages/man2/getrlimit.2.html), [proc.5](https://man7.org/linux/man-pages/man5/proc.5.html), [open.2](https://man7.org/linux/man-pages/man2/open.2.html), [signal.7](https://man7.org/linux/man-pages/man7/signal.7.html), [times.2](https://man7.org/linux/man-pages/man2/times.2.html), [getpagesize.2](https://man7.org/linux/man-pages/man2/getpagesize.2.html)
