# Week05-class02 실습 · 시간과 시계

Ubuntu 일반 사용자 환경에서 달력 시간 조회, 경과 시간 측정, 타임스탬프 로그를 실습합니다. 준비 도구는 `cc`, `make`, `python3`입니다. 명령은 이 README가 있는 폴더에서 실행합니다.

```sh
make
make check
```

| 예제 | 학습 내용 |
|---|---|
| calendar_demo.c | time(2), localtime·gmtime·strftime, difftime, TZ 환경변수 |
| tm_normalize.c | struct tm 직접 채우기, mktime 정규화, tm_mon 0 기반, 윤년 |
| elapsed_demo.c | clock_gettime·CLOCK_MONOTONIC, 나노초 정수 차이, 반복 측정 |
| tslog.c | 타임스탬프 로그(달력+경과), 추가 모드, fflush |
| clock_show.c | 시계별 값·해상도(clock_getres), 미지원 시계 처리 |

Makefile은 C11과 POSIX API를 사용하며 경고를 오류로 처리합니다. `_POSIX_C_SOURCE=200809L`은 clock_gettime 등 POSIX 2008 인터페이스를, `_DEFAULT_SOURCE`와 `_DARWIN_C_SOURCE`는 각각 Linux와 macOS의 추가 상수 선언을 위한 설정입니다.

시간·측정 값은 실행 환경마다 다릅니다. 숫자를 고정하지 말고, 서로 다른 문(프로그램·명령)에서 같은 값이 나오는지와 시계·시간대의 관계를 기록하는 것이 이번 실습의 목표입니다.

## 실습 1 · 달력 시간

같은 터미널에서 이어서 실행합니다.

```sh
TZ=Asia/Seoul ./calendar_demo
TZ=UTC ./calendar_demo
./tm_normalize
date; date -u; date +%s
```

관찰할 점:

- `epoch` 값이 `date +%s`와 같은 초 단위인지 확인합니다. 두 문이 같은 값을 주면 조회가 정확한 것입니다.
- `local` 문자열이 서울과 UTC에서 정확히 9시간 차이인지 확인합니다. `utc` 문자열은 TZ와 무관하게 같아야 합니다.
- `difftime` 값은 두 `time(2)` 판독 사이에 약 1.2초를 기다린 결과입니다. time(2)의 해상도가 초 단위라는 점을 확인합니다.
- `tm_normalize`의 네 사례를 채웁니다: 2026-01-32는 2026-02-01로, 2026-12-32는 2027-01-01로 정규화됩니다. 2025-02-29(평년)는 2025-03-01이 되고 2024-02-29(윤년)는 그대로입니다.
- `tm_mon`이 0부터 센다는 점을 출력의 `(tm_mon=0)`·`(tm_mon=1)` 표시로 확인합니다.

## 실습 2 · 경과 시간 측정

```sh
./elapsed_demo
./elapsed_demo --clocks
./clock_show

# 나노초를 밀리초로 환산하는 연습
python3 -c 'print(3492000/1e6, "ms")'
```

관찰할 점:

- `run1`부터 `run5`까지 값을 적고 `min`·`median`·`max`를 직접 계산해 봅니다. 매번 값이 달라도 `min <= median <= max` 관계는 유지됩니다.
- 같은 작업을 다섯 번 재는 이유와 워밍업이 첫 측정의 캐시 효과를 줄인다는 점을 설명합니다.
- `--clocks`에서 `CLOCK_REALTIME`의 `now`는 에포크 초(=`date +%s`와 같은 단위), `CLOCK_MONOTONIC`의 `now`는 부팅 후 초입니다. 두 값의 규모 차이로 어느 시계인지 구분합니다.
- `res`는 그 시계의 해상도입니다. 환경에 따라 `0.000001000`(마이크로초 눈금)처럼 나옵니다. 나노초 필드가 있어도 눈금은 다를 수 있습니다.
- 측정 코드가 `volatile` 배열을 쓰는 이유(컴파일러의 상수폴딩 방지)를 소스에서 확인합니다.

## 실습 3 · 타임스탬프 로그

```sh
TZ=Asia/Seoul ./tslog --demo
./tslog -o run.log --demo
./tslog -o run.log 'second run'
cat run.log

# read config와 process data의 간격 계산
python3 -c 'print(24.5-12.5, "ms")'
```

관찰할 점:

- 로그 한 줄이 달력 시각 + 경과 시간 + 메시지 세 부분으로 구성되어 있는지 확인합니다.
- 인접한 줄의 경과 시간 차가 각 단계의 지속 시간(약 12ms)입니다. 데모의 간격은 `spin_ns`로 만든 의도된 값입니다.
- 같은 파일로 두 번 실행해 줄이 이어지는지 확인합니다. `-o`는 추가 모드로 여는 것을 소스에서 확인합니다.
- 메시지를 인자로 주면 화면(stderr)에 기록됩니다. 로그를 쓴 뒤 `fflush`하는 이유를 설명합니다.

## 실습 4 · 시계 비교 관찰

```sh
./clock_show
./elapsed_demo --clocks
date +%s
TZ=Asia/Seoul date; TZ=UTC date

# (Linux 선택) 부팅 후 시간 규모 비교
cat /proc/uptime
```

관찰할 점:

- `CLOCK_REALTIME`과 `CLOCK_MONOTONIC`의 `now`·`res`를 표로 정리합니다. 원점과 용도가 다르다는 점을 함께 적습니다.
- 미지원 시계가 `unsupported`로 표시되고 프로그램이 계속되는지 확인합니다. 시스템마다 있는 시계가 다릅니다.
- Linux에서는 `/proc/uptime`의 첫 값이 `CLOCK_MONOTONIC`의 `now`와 비슷한 규모인지 봅니다. macOS에는 /proc가 없으므로 이 줄은 건너뜁니다.
- `CLOCK_PROCESS_CPUTIME_ID`의 `now`가 매우 작은 이유(그 프로세스가 쓴 CPU 시간)를 적습니다. 다음 주 times(2)와 이어집니다.

## 종료 상태와 제출

- 0: 정상 완료
- 1: 조회·측정·기록 실패 (미지원 시계 표시는 실패가 아님)
- 2: 잘못된 실행 인자

실패 직후 `echo $?`를 실행합니다. 의도적인 실패가 있으므로 모든 명령을 `set -e`로 일괄 실행하지 않습니다.

제출물은 C 소스 5개, Makefile, 작성한 REPORT.md, 정상·실패 실행 로그입니다. 선택 과제는 `tslog`에 경과 시간 표시 단위를 바꾸는 옵션(예: `--unit ms`)을 추가하는 것입니다.

## 실행 확인 범위

2026-09-27 macOS arm64에서 다섯 예제를 경고 없이 컴파일하고 자동 검사 16회 실행을 통과했습니다. TZ별 local·utc 9시간 차이, mktime 정규화 4사례, 측정값 분포와 시계 조회, 로그 형식·단조 증가·추가 모드, 미지원 인자의 오류 경로를 검사했습니다. Linux 실행은 이번 제작 환경에서 확인하지 않았으므로 수업용 Ubuntu에서 `make check`로 재확인할 수 있습니다.

## 참고

[time(2)](https://man7.org/linux/man-pages/man2/time.2.html), [difftime(3)](https://man7.org/linux/man-pages/man3/difftime.3.html), [clock_gettime(2)](https://man7.org/linux/man-pages/man2/clock_gettime.2.html), [ctime(3)](https://man7.org/linux/man-pages/man3/ctime.3.html), [strftime(3)](https://man7.org/linux/man-pages/man3/strftime.3.html), [tzset(3)](https://man7.org/linux/man-pages/man3/tzset.3.html).
