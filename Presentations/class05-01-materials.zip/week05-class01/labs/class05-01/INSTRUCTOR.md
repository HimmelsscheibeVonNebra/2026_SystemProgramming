# 교수자 안내 · 시스템 정보와 자원 한계

전체 수업 대본은 상위 폴더의 week05-class01-script.md입니다. 실습은 완성 소스의 핵심 분기를 읽고, 실행 전에 예상한 값을 실제 결과와 비교하는 방식입니다. 값 자체가 환경마다 다르므로 숫자 일치가 아니라 교차 확인과 변경 전후 관계를 봅니다.

## 핵심 확인 사항

- sysprobe는 uname 뒤 sysconf 다섯 값을 같은 probe 함수로 출력합니다. probe는 호출 직전 errno를 0으로 만들고 -1을 errno 유무로 두 갈래로 나눕니다. 이 순서가 sysconf 계약의 전부입니다.
- sysconf(_SC_OPEN_MAX)는 RLIMIT_NOFILE의 soft 한계 값과 같습니다. getconf OPEN_MAX, ulimit -Sn과 교차 확인하는 것이 실습 2의 목적입니다.
- uname(1) 명령과 uname(2) 함수가 같은 정보를 주는지 학생이 직접 대응시키게 합니다. macOS 실습 환경에서는 sysname=Darwin, pagesize=16384처럼 다른 값이 나오는 것 자체가 학습 자료입니다.
- limit_show의 두 열은 rlim_cur와 rlim_max입니다. RLIM_INFINITY는 unlimited로 표시합니다.
- nofile_demo의 opened는 soft보다 작습니다. 표준 입출력 오류 FD 세 개가 이미 열려 있고 환경에 따라 더 열려 있을 수 있습니다. 근처 값이면 정상입니다.
- nofile_demo --raise는 hard를 넘는 요청을 hard로 제한합니다. 셸에서 hard 초과 상향은 허용 오류가 나는 것과 비교하게 하면 soft·hard 관계가 분명해집니다.
- bash에서 ulimit -Sn N은 soft만 바꿉니다. -S 없이 ulimit -n N은 soft와 hard를 함께 바꾸므로 hard를 되돌릴 수 없게 됩니다. 실습에서는 -Sn만 씁니다.
- proc_probe의 fd 개수는 /proc/self/fd를 여는 스트림 자체가 FD 하나를 추가합니다. grep /proc/self/status의 self는 grep 프로세스 자신이므로 명령마다 값이 다른 것이 정상입니다.
- sysinfo_demo는 #ifdef __linux__로 조건부 컴파일을 보여줍니다. Linux가 아니면 안내 문장과 종료 상태 1을 반환합니다. 이식성과 플랫폼 확장을 구분하는 사례로 활용합니다.

## 퀴즈 정답

1. sysconf가 -1: 조회 실패(errno가 0이 아님)와 무한·미정의(errno가 0)로 나뉩니다. 호출 직전 errno를 0으로 초기화한 뒤 구분합니다.
2. 일반 사용자: soft는 hard까지 상향할 수 있고, hard를 낮추면 되돌릴 수 없습니다.
3. EMFILE입니다.
4. RLIMIT_NOFILE의 soft 한계 값과 같습니다.
5. /proc는 Linux 고유이므로 이식성이 없습니다. 판단 근거는 표준 API에서 얻습니다.

## 설명을 평가하는 기준

실제 배점은 수업 운영에 맞게 정합니다. 숫자의 일치보다 단위·출처·변경 전후 관계를 봅니다. sysconf의 errno 초기화를 설명했는지, soft와 hard의 변경 규칙을 말했는지, /proc 값이 프로세스마다 다른 이유를 설명했는지 확인합니다.

## 진행 문제 해결

- sysprobe 실행 인자 오류: 인자를 받지 않는 프로그램입니다. usage 안내 후 종료 상태 2가 정상입니다.
- nofile_demo --raise 후 opened가 64보다 작음: 표준 FD와 기존 열린 FD가 있기 때문입니다. 정확한 차이를 채점하지 않습니다.
- bash에서 ulimit -Sn 4096이 실패: 현재 hard가 4096보다 작기 때문입니다. hard 값을 먼저 확인하고 hard 이하로 실험합니다.
- macOS에서 getconf 일부 값이 비거나 다름: 일부 항목은 Linux 전용입니다. 있는 항목만 비교하게 합니다.
- strace가 없는 환경: Ubuntu에서 설치하거나(sudo apt install strace) 해당 관찰은 건너뜁니다.
- /proc가 없는 환경: proc_probe가 오류 경로를 보여주는 것도 관찰 결과입니다. Linux 환경에서 다시 실행하게 합니다.
- 값이 매번 조금씩 다름: loadavg·VmRSS 등은 읽는 순간마다 다릅니다. 큰 그림(같은 문에서 일치, 다른 문에서 차이)을 보게 합니다.
