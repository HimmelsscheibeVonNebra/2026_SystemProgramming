# Week05-class02 · 시간과 시계: 경과 시간과 달력 시간

본문 35장과 챕터별 코드 읽기 36장(총 71장), 120분 수업 자료입니다. week04·week05-class01 디자인을 이어 사용하며, 시간을 '보여 주는 용도'와 '재는 용도'로 구분하는 것이 이번 차시의 중심 문제입니다.

## 챕터별 코드 읽기

예제 다섯 개의 소스 전체를 줄 번호와 함께 실은 코드 읽기 슬라이드가 각 부의 실습 바로 뒤에 배치되어 있습니다. `→` 화살표 줄이 바로 위 코드 줄(또는 앞 범위)의 설명이며, 색으로 구분됩니다: 줄번호는 회색, 코드는 남색, 설명은 파란색. 120분 강의에서는 발췌 슬라이드로 핵심만 다루고, 전체 읽기는 실습 시간에 소스를 함께 열어 한 줄씩 읽거나 복습 자료로 사용합니다. 목록은 `labs/class05-02`의 실제 컴파일 대상 소스에서 줄 단위로 생성했으므로 편집기의 줄 번호와 그대로 일치합니다.

| 배치 | 예제 | 분량 | 슬라이드 |
|---|---|---|---|
| 1부 달력 시간 뒤 | calendar_demo.c | 68줄 | 10–15장 |
| 1부 달력 시간 뒤 | tm_normalize.c | 55줄 | 16–20장 |
| 2부 경과 시간 뒤 | elapsed_demo.c | 104줄 | 29–37장 |
| 3부 시간 기록 뒤 | tslog.c | 135줄 | 47–57장 |
| 4부 시계 선택 뒤 | clock_show.c | 51줄 | 64–68장 |

## 자료 구성

| 파일 | 용도 |
|---|---|
| [week05-class02.odp](week05-class02.odp) | LibreOffice Impress 편집본 |
| [week05-class02.pptx](week05-class02.pptx) | PowerPoint 편집본 |
| [week05-class02.pdf](week05-class02.pdf) | 학생 배포·인쇄용, 71쪽 |
| [week05-class02.md](week05-class02.md) | 슬라이드 내용과 발표자 노트, 참고 문서 |
| [week05-class02-script.md](week05-class02-script.md) | 설명 멘트·시연·질문을 포함한 120분 대본 |
| [labs/class05-02/README.md](labs/class05-02/README.md) | C 실습 5개와 실행 안내 |
| [labs/class05-02/REPORT.md](labs/class05-02/REPORT.md) | 학생용 예측·관찰·해석 기록지 |
| [labs/class05-02/INSTRUCTOR.md](labs/class05-02/INSTRUCTOR.md) | 교수자용 해설과 퀴즈 답안 |

ZIP을 풀면 `week05-class02/` 폴더 아래에 교안과 실습이 함께 있습니다. ZIP 안에서는 이 안내 파일의 이름이 `README.md`입니다.

## 학습 목표

- time(2)·difftime(3)으로 달력 시간을 얻고 에포크 기준을 설명한다.
- localtime·gmtime·mktime·strftime(3)으로 time_t와 struct tm·문자열을 오가며 tm_mon 0 기반·tm_isdst를 다룬다.
- clock_gettime(2)·struct timespec으로 경과 시간을 재고 나노초 정수 차이 계산을 구현한다.
- CLOCK_REALTIME과 CLOCK_MONOTONIC의 차이(점프 가능성·기준점)를 측정 용도와 표시 용도로 구분한다.
- 타임스탬프 로그를 직접 만들어 달력 시각과 경과 시간을 함께 기록하고 추가 모드·fflush의 의미를 설명한다.

## 수업 흐름

| 시간 | 교안 슬라이드 | 주제 |
|---|---|---|
| 00–10분 | 1–3 | 복습: 실행 환경에서 시간으로 |
| 10–30분 | 4–9 | 달력 시간(time·localtime·strftime), 실습 1 |
| 실습·복습 시간 | 10–20 | 코드 읽기: calendar_demo·tm_normalize |
| 30–40분 | — | 휴식 |
| 40–65분 | 21–28 | 경과 시간(clock_gettime·MONOTONIC), 실습 2 |
| 실습·복습 시간 | 29–37 | 코드 읽기: elapsed_demo |
| 65–95분 | 38–46 | 시간 기록(타임스탬프 로그), 실습 3 |
| 실습·복습 시간 | 47–57 | 코드 읽기: tslog |
| 95–115분 | 58–63 | 시계 선택과 함정, 실습 4 |
| 실습·복습 시간 | 64–68 | 코드 읽기: clock_show |
| 115–120분 | 69–71 | 확인 퀴즈, 제출, 참고 문서 |

## 실습 시작

Ubuntu의 일반 사용자 환경에서 `cc`, `make`, `python3`를 준비합니다. 다음 명령은 자료의 최상위 폴더에서 실행합니다.

```sh
cd labs/class05-02
make
make check
```

예제는 `calendar_demo`, `tm_normalize`, `elapsed_demo`, `tslog`, `clock_show`입니다. 순서대로 실습 README의 명령을 실행하고 REPORT.md를 작성합니다. 각 프로그램의 소스와 Makefile을 포함했으므로 수업 환경에서 직접 컴파일합니다.

시간·측정 값은 환경마다 다릅니다. 채점 기준은 숫자 일치가 아니라 두 문(프로그램·명령)에서 같은 값을 얻었는지, 시간대·시계의 관계를 설명했는지입니다.

## 진도 연결

첫 차시가 프로그램의 실행 환경을 조회했다면 이번 차시는 실행 환경 속에서 시간을 다룹니다. 첫 차시에 다룬 CLK_TCK·sysconf는 다음 주 프로세스 정보에서 times(2)와 다시 만나고, 오늘의 CLOCK_MONOTONIC은 9주차 시그널 타임아웃과 11주차 mmap 성능 측정에서 계속 쓰입니다. 타임스탬프 로그는 캡스톤 미니 셸의 작업 기록으로 확장됩니다.

## 편집과 참고

교안 글꼴은 `Noto Sans CJK KR`, 코드 글꼴은 `Noto Sans Mono CJK KR`입니다. 편집 환경에 글꼴이 없으면 줄바꿈이 달라질 수 있으며, 배포용 PDF는 제작 시의 배치를 유지합니다.

API 출처는 슬라이드 발표자 노트와 Markdown 교안에 연결했습니다. 주요 문서는 Linux man-pages의 [time(2)](https://man7.org/linux/man-pages/man2/time.2.html), [clock_gettime(2)](https://man7.org/linux/man-pages/man2/clock_gettime.2.html), [ctime(3)](https://man7.org/linux/man-pages/man3/ctime.3.html), [strftime(3)](https://man7.org/linux/man-pages/man3/strftime.3.html)입니다.

## 실행 확인 범위

자료 제작 시 macOS arm64에서 C 예제 5개의 컴파일과 자동 검사 16회 실행을 통과했습니다. Linux 실행은 제작 환경에서 확인하지 않았습니다. Ubuntu에서 `make check`로 확인하며, CLOCK_MONOTONIC_RAW 등 일부 시계와 /proc/uptime 관찰은 시스템에 따라 결과가 다릅니다.
