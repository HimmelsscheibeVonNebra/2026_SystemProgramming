# Week05-class01 · 시스템 정보와 자원 한계

35장 교안과 120분 수업 자료입니다. week04 디자인을 이어 사용하며, 프로그램이 실행 환경을 알아내는 표준 API와 Linux 관찰 창을 구분하는 것이 이번 차시의 중심 문제입니다.

## 자료 구성

| 파일 | 용도 |
|---|---|
| [week05-class01.odp](week05-class01.odp) | LibreOffice Impress 편집본 |
| [week05-class01.pptx](week05-class01.pptx) | PowerPoint 편집본 |
| [week05-class01.pdf](week05-class01.pdf) | 학생 배포·인쇄용, 35쪽 |
| [week05-class01.md](week05-class01.md) | 슬라이드 내용과 발표자 노트, 참고 문서 |
| [week05-class01-script.md](week05-class01-script.md) | 설명 멘트·시연·질문을 포함한 120분 대본 |
| [labs/class05-01/README.md](labs/class05-01/README.md) | C 실습 5개와 실행 안내 |
| [labs/class05-01/REPORT.md](labs/class05-01/REPORT.md) | 학생용 예측·관찰·해석 기록지 |
| [labs/class05-01/INSTRUCTOR.md](labs/class05-01/INSTRUCTOR.md) | 교수자용 해설과 퀴즈 답안 |

ZIP을 풀면 `week05-class01/` 폴더 아래에 교안과 실습이 함께 있습니다. ZIP 안에서는 이 안내 파일의 이름이 `README.md`입니다.

## 학습 목표

- uname(2)과 struct utsname으로 시스템을 식별하고 uname(1) 명령과 대응시킨다.
- sysconf(3)의 반환값 계약을 설명한다: 호출 전 errno 초기화와 -1의 두 가지 의미.
- getrlimit(2)·setrlimit(2)로 soft·hard 한계를 조회하고 조건 안에서 변경한다.
- RLIMIT_NOFILE에 도달한 open이 EMFILE으로 실패하는 것을 관찰한다.
- /proc/self의 상태·한계·열린 FD를 읽고 표준 API와의 역할 분담을 설명한다.

## 수업 흐름

| 시간 | 슬라이드 | 주제 |
|---|---|---|
| 00–10분 | 1–3 | 복습: 파일에서 실행 환경으로 |
| 10–30분 | 4–9 | uname·sysinfo와 실습 1 |
| 30–40분 | — | 휴식 |
| 40–65분 | 10–17 | sysconf 반환 계약·pathconf, 실습 2 |
| 65–95분 | 18–26 | getrlimit·setrlimit와 FD 한계, 실습 3 |
| 95–115분 | 27–32 | /proc 관찰 창, 실습 4 |
| 115–120분 | 33–35 | 확인 퀴즈, 제출, 참고 문서 |

## 실습 시작

Ubuntu의 일반 사용자 환경에서 `cc`, `make`, `python3`를 준비합니다. 다음 명령은 자료의 최상위 폴더에서 실행합니다.

```sh
cd labs/class05-01
make
make check
```

예제는 `sysprobe`, `limit_show`, `nofile_demo`, `proc_probe`, `sysinfo_demo`입니다. 순서대로 실습 README의 명령을 실행하고 REPORT.md를 작성합니다. 각 프로그램의 소스와 Makefile을 포함했으므로 수업 환경에서 직접 컴파일합니다.

출력 값은 환경마다 다릅니다. 채점 기준은 숫자 일치가 아니라 두 문(프로그램·명령)에서 같은 값을 얻었는지, 한계 변경 전후의 관계를 설명했는지입니다.

## 진도 연결

3–4주차가 파일의 내용·속성·이름을 다뤘다면 이번 차시부터는 프로그램 자신의 실행 환경을 다룹니다. 2주차에 잠깐 실행한 uname·sysconf 예제를 반환값 계약까지 깊이 있게 다시 다루고, _SC_PAGESIZE는 11주 mmap에서, CLK_TCK는 6주차 시간 처리에서, EMFILE·시그널 초과는 9주차 시그널에서 다시 만납니다. 5주차 두 번째 수업은 시간·시계·로그(경과 시간과 달력 시간)로 이어집니다.

## 편집과 참고

교안 글꼴은 `Noto Sans CJK KR`, 코드 글꼴은 `Noto Sans Mono CJK KR`입니다. 편집 환경에 글꼴이 없으면 줄바꿈이 달라질 수 있으며, 배포용 PDF는 제작 시의 배치를 유지합니다.

API 출처는 슬라이드 발표자 노트와 Markdown 교안에 연결했습니다. 주요 문서는 Linux man-pages의 [uname(2)](https://man7.org/linux/man-pages/man2/uname.2.html), [sysconf(3)](https://man7.org/linux/man-pages/man3/sysconf.3.html), [getrlimit(2)](https://man7.org/linux/man-pages/man2/getrlimit.2.html), [proc(5)](https://man7.org/linux/man-pages/man5/proc.5.html)입니다.

## 실행 확인 범위

자료 제작 시 macOS arm64에서 C 예제 5개의 컴파일과 자동 검사 9회 실행을 통과했습니다. Linux 실행은 제작 환경에서 확인하지 않았습니다. Ubuntu에서 `make check`로 확인하며, sysinfo와 /proc 실습은 Linux에서만 전체 결과가 나옵니다.
