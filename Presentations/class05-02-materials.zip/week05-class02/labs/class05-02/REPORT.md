# Week05-class02 · 시간과 시계 실습 기록지

- 이름 / 학번:
- 운영체제·커널 릴리스·아키텍처:
- 실행한 빌드 명령과 결과:

## 1. 달력 시간

| 항목 | calendar_demo 출력 (TZ=Asia/Seoul) | calendar_demo 출력 (TZ=UTC) | date 명령 출력 |
|---|---|---|---|
| epoch | | | date +%s |
| local | | | date |
| utc | | | date -u |

- Seoul과 UTC의 local 문자열 시각 차이:
- utc 문자열이 TZ와 무관하게 같은 이유:
- difftime으로 잰 대략의 값과, 짧은 간격(1초 미만)을 time(2)로 잴 수 없는 이유:

| tm_normalize 사례 | 입력 (tm_mon) | mktime 결과 | 왜 그렇게 되는가 |
|---|---|---|---|
| 2026-01-32 | 0 | | |
| 2026-12-32 | 11 | | |
| 2025-02-29 | 1 | | |
| 2024-02-29 | 1 | | |

## 2. 경과 시간 측정

| 측정 | 값 (ns) |
|---|---|
| run1 | |
| run2 | |
| run3 | |
| run4 | |
| run5 | |
| min | |
| median | |

- min을 밀리초로 환산한 값:
- 다섯 번 재는 이유와 값이 매번 달라지는 원인:
- elapsed_demo의 측정 코드가 volatile 배열을 쓰는 이유:

| 시계 | now 값 | res 값 | 원점(기준점) |
|---|---|---|---|
| CLOCK_REALTIME | | | 에포크(1970-01-01 UTC) |
| CLOCK_MONOTONIC | | | 부팅 이후 |

## 3. 타임스탬프 로그

- `TZ=Asia/Seoul ./tslog --demo` 출력 5줄을 그대로 붙여넣습니다:

- read config → process data 간격(ms) 계산 과정과 결과:
- 같은 파일에 두 번 실행했을 때 줄 수 변화와 그 이유(추가 모드):
- 로그를 쓴 뒤 fflush하는 이유:

## 4. 시계 비교

- `date +%s` 값과 CLOCK_REALTIME now 값의 관계:
- CLOCK_PROCESS_CPUTIME_ID의 now가 매우 작은 이유:
- (Linux) /proc/uptime 첫 값과 CLOCK_MONOTONIC now의 규모 비교, 또는 macOS에서 건너뛴 기록:
- 미지원 시계가 어떻게 표시되는지와 프로그램이 계속되는 이유:

## 5. 정리

- 경과 시간을 잴 때 CLOCK_MONOTONIC을 쓰는 이유:
- time_t → struct tm → 문자열로 가는 호출 순서와 각 단계의 실패 표시(-1·NULL·0):
- 로그 한 줄에 달력 시각과 경과 시간을 함께 남기는 이유:
